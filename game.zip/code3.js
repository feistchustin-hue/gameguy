gdjs.tutorial_47backgroundCode = {};
gdjs.tutorial_47backgroundCode.localVariables = [];
gdjs.tutorial_47backgroundCode.idToCallbackMap = new Map();
gdjs.tutorial_47backgroundCode.GDbeginingObjects1= [];
gdjs.tutorial_47backgroundCode.GDbeginingObjects2= [];
gdjs.tutorial_47backgroundCode.GDgo_9595back_9595to_9595level_95952Objects1= [];
gdjs.tutorial_47backgroundCode.GDgo_9595back_9595to_9595level_95952Objects2= [];
gdjs.tutorial_47backgroundCode.GDhearts_9595lifeObjects1= [];
gdjs.tutorial_47backgroundCode.GDhearts_9595lifeObjects2= [];
gdjs.tutorial_47backgroundCode.GDhearts_9595life2Objects1= [];
gdjs.tutorial_47backgroundCode.GDhearts_9595life2Objects2= [];
gdjs.tutorial_47backgroundCode.GDhearts_9595life3Objects1= [];
gdjs.tutorial_47backgroundCode.GDhearts_9595life3Objects2= [];
gdjs.tutorial_47backgroundCode.GDball_9595guyObjects1= [];
gdjs.tutorial_47backgroundCode.GDball_9595guyObjects2= [];
gdjs.tutorial_47backgroundCode.GDguy_9595sprite_9595cloneObjects1= [];
gdjs.tutorial_47backgroundCode.GDguy_9595sprite_9595cloneObjects2= [];
gdjs.tutorial_47backgroundCode.GDguy_9595spriteObjects1= [];
gdjs.tutorial_47backgroundCode.GDguy_9595spriteObjects2= [];
gdjs.tutorial_47backgroundCode.GDtimekeeperObjects1= [];
gdjs.tutorial_47backgroundCode.GDtimekeeperObjects2= [];
gdjs.tutorial_47backgroundCode.GDdeathblockObjects1= [];
gdjs.tutorial_47backgroundCode.GDdeathblockObjects2= [];
gdjs.tutorial_47backgroundCode.GDkey2Objects1= [];
gdjs.tutorial_47backgroundCode.GDkey2Objects2= [];
gdjs.tutorial_47backgroundCode.GDscoreboardObjects1= [];
gdjs.tutorial_47backgroundCode.GDscoreboardObjects2= [];
gdjs.tutorial_47backgroundCode.GDdoorObjects1= [];
gdjs.tutorial_47backgroundCode.GDdoorObjects2= [];
gdjs.tutorial_47backgroundCode.GDno_9595keyObjects1= [];
gdjs.tutorial_47backgroundCode.GDno_9595keyObjects2= [];
gdjs.tutorial_47backgroundCode.GDcoinObjects1= [];
gdjs.tutorial_47backgroundCode.GDcoinObjects2= [];
gdjs.tutorial_47backgroundCode.GDplatform_9595viruseObjects1= [];
gdjs.tutorial_47backgroundCode.GDplatform_9595viruseObjects2= [];
gdjs.tutorial_47backgroundCode.GDboss_9595heartObjects1= [];
gdjs.tutorial_47backgroundCode.GDboss_9595heartObjects2= [];
gdjs.tutorial_47backgroundCode.GDboss_9595heart2Objects1= [];
gdjs.tutorial_47backgroundCode.GDboss_9595heart2Objects2= [];
gdjs.tutorial_47backgroundCode.GDboss_9595heart3Objects1= [];
gdjs.tutorial_47backgroundCode.GDboss_9595heart3Objects2= [];
gdjs.tutorial_47backgroundCode.GDevile_9595guyObjects1= [];
gdjs.tutorial_47backgroundCode.GDevile_9595guyObjects2= [];
gdjs.tutorial_47backgroundCode.GDguy_9595sprite2Objects1= [];
gdjs.tutorial_47backgroundCode.GDguy_9595sprite2Objects2= [];
gdjs.tutorial_47backgroundCode.GDguy_9595sprite_9595clone2Objects1= [];
gdjs.tutorial_47backgroundCode.GDguy_9595sprite_9595clone2Objects2= [];


gdjs.tutorial_47backgroundCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("go_back_to_level_2"), gdjs.tutorial_47backgroundCode.GDgo_9595back_9595to_9595level_95952Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.tutorial_47backgroundCode.GDgo_9595back_9595to_9595level_95952Objects1.length;i<l;++i) {
    if ( gdjs.tutorial_47backgroundCode.GDgo_9595back_9595to_9595level_95952Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.tutorial_47backgroundCode.GDgo_9595back_9595to_9595level_95952Objects1[k] = gdjs.tutorial_47backgroundCode.GDgo_9595back_9595to_9595level_95952Objects1[i];
        ++k;
    }
}
gdjs.tutorial_47backgroundCode.GDgo_9595back_9595to_9595level_95952Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 2", false);
}
}

}


};

gdjs.tutorial_47backgroundCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.tutorial_47backgroundCode.GDbeginingObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDbeginingObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDgo_9595back_9595to_9595level_95952Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDgo_9595back_9595to_9595level_95952Objects2.length = 0;
gdjs.tutorial_47backgroundCode.GDhearts_9595lifeObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDhearts_9595lifeObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDhearts_9595life2Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDhearts_9595life2Objects2.length = 0;
gdjs.tutorial_47backgroundCode.GDhearts_9595life3Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDhearts_9595life3Objects2.length = 0;
gdjs.tutorial_47backgroundCode.GDball_9595guyObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDball_9595guyObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595spriteObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595spriteObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDtimekeeperObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDtimekeeperObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDdeathblockObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDdeathblockObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDkey2Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDkey2Objects2.length = 0;
gdjs.tutorial_47backgroundCode.GDscoreboardObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDscoreboardObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDdoorObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDdoorObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDno_9595keyObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDno_9595keyObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDcoinObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDcoinObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDplatform_9595viruseObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDplatform_9595viruseObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDboss_9595heartObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDboss_9595heartObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDboss_9595heart2Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDboss_9595heart2Objects2.length = 0;
gdjs.tutorial_47backgroundCode.GDboss_9595heart3Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDboss_9595heart3Objects2.length = 0;
gdjs.tutorial_47backgroundCode.GDevile_9595guyObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDevile_9595guyObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595sprite2Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595sprite2Objects2.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595sprite_9595clone2Objects2.length = 0;

gdjs.tutorial_47backgroundCode.eventsList0(runtimeScene);
gdjs.tutorial_47backgroundCode.GDbeginingObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDbeginingObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDgo_9595back_9595to_9595level_95952Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDgo_9595back_9595to_9595level_95952Objects2.length = 0;
gdjs.tutorial_47backgroundCode.GDhearts_9595lifeObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDhearts_9595lifeObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDhearts_9595life2Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDhearts_9595life2Objects2.length = 0;
gdjs.tutorial_47backgroundCode.GDhearts_9595life3Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDhearts_9595life3Objects2.length = 0;
gdjs.tutorial_47backgroundCode.GDball_9595guyObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDball_9595guyObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595spriteObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595spriteObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDtimekeeperObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDtimekeeperObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDdeathblockObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDdeathblockObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDkey2Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDkey2Objects2.length = 0;
gdjs.tutorial_47backgroundCode.GDscoreboardObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDscoreboardObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDdoorObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDdoorObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDno_9595keyObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDno_9595keyObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDcoinObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDcoinObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDplatform_9595viruseObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDplatform_9595viruseObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDboss_9595heartObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDboss_9595heartObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDboss_9595heart2Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDboss_9595heart2Objects2.length = 0;
gdjs.tutorial_47backgroundCode.GDboss_9595heart3Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDboss_9595heart3Objects2.length = 0;
gdjs.tutorial_47backgroundCode.GDevile_9595guyObjects1.length = 0;
gdjs.tutorial_47backgroundCode.GDevile_9595guyObjects2.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595sprite2Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595sprite2Objects2.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.tutorial_47backgroundCode.GDguy_9595sprite_9595clone2Objects2.length = 0;


return;

}

gdjs['tutorial_47backgroundCode'] = gdjs.tutorial_47backgroundCode;
