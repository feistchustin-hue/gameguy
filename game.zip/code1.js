gdjs.winCode = {};
gdjs.winCode.localVariables = [];
gdjs.winCode.idToCallbackMap = new Map();
gdjs.winCode.GDYOU_9595WIN_9595TEXTObjects1= [];
gdjs.winCode.GDYOU_9595WIN_9595TEXTObjects2= [];
gdjs.winCode.GDYOU_9595WIN_9595TEXTObjects3= [];
gdjs.winCode.GDBlackDecoratedButtonObjects1= [];
gdjs.winCode.GDBlackDecoratedButtonObjects2= [];
gdjs.winCode.GDBlackDecoratedButtonObjects3= [];
gdjs.winCode.GDlevel1timedisplayObjects1= [];
gdjs.winCode.GDlevel1timedisplayObjects2= [];
gdjs.winCode.GDlevel1timedisplayObjects3= [];
gdjs.winCode.GDBlackDecoratedButton2Objects1= [];
gdjs.winCode.GDBlackDecoratedButton2Objects2= [];
gdjs.winCode.GDBlackDecoratedButton2Objects3= [];
gdjs.winCode.GDscoreboardObjects1= [];
gdjs.winCode.GDscoreboardObjects2= [];
gdjs.winCode.GDscoreboardObjects3= [];
gdjs.winCode.GDhearts_9595lifeObjects1= [];
gdjs.winCode.GDhearts_9595lifeObjects2= [];
gdjs.winCode.GDhearts_9595lifeObjects3= [];
gdjs.winCode.GDhearts_9595life2Objects1= [];
gdjs.winCode.GDhearts_9595life2Objects2= [];
gdjs.winCode.GDhearts_9595life2Objects3= [];
gdjs.winCode.GDhearts_9595life3Objects1= [];
gdjs.winCode.GDhearts_9595life3Objects2= [];
gdjs.winCode.GDhearts_9595life3Objects3= [];
gdjs.winCode.GDball_9595guyObjects1= [];
gdjs.winCode.GDball_9595guyObjects2= [];
gdjs.winCode.GDball_9595guyObjects3= [];
gdjs.winCode.GDguy_9595sprite_9595cloneObjects1= [];
gdjs.winCode.GDguy_9595sprite_9595cloneObjects2= [];
gdjs.winCode.GDguy_9595sprite_9595cloneObjects3= [];
gdjs.winCode.GDguy_9595spriteObjects1= [];
gdjs.winCode.GDguy_9595spriteObjects2= [];
gdjs.winCode.GDguy_9595spriteObjects3= [];
gdjs.winCode.GDtimekeeperObjects1= [];
gdjs.winCode.GDtimekeeperObjects2= [];
gdjs.winCode.GDtimekeeperObjects3= [];
gdjs.winCode.GDdeathblockObjects1= [];
gdjs.winCode.GDdeathblockObjects2= [];
gdjs.winCode.GDdeathblockObjects3= [];
gdjs.winCode.GDkey2Objects1= [];
gdjs.winCode.GDkey2Objects2= [];
gdjs.winCode.GDkey2Objects3= [];
gdjs.winCode.GDscoreboardObjects1= [];
gdjs.winCode.GDscoreboardObjects2= [];
gdjs.winCode.GDscoreboardObjects3= [];
gdjs.winCode.GDdoorObjects1= [];
gdjs.winCode.GDdoorObjects2= [];
gdjs.winCode.GDdoorObjects3= [];
gdjs.winCode.GDno_9595keyObjects1= [];
gdjs.winCode.GDno_9595keyObjects2= [];
gdjs.winCode.GDno_9595keyObjects3= [];
gdjs.winCode.GDcoinObjects1= [];
gdjs.winCode.GDcoinObjects2= [];
gdjs.winCode.GDcoinObjects3= [];
gdjs.winCode.GDplatform_9595viruseObjects1= [];
gdjs.winCode.GDplatform_9595viruseObjects2= [];
gdjs.winCode.GDplatform_9595viruseObjects3= [];
gdjs.winCode.GDboss_9595heartObjects1= [];
gdjs.winCode.GDboss_9595heartObjects2= [];
gdjs.winCode.GDboss_9595heartObjects3= [];
gdjs.winCode.GDboss_9595heart2Objects1= [];
gdjs.winCode.GDboss_9595heart2Objects2= [];
gdjs.winCode.GDboss_9595heart2Objects3= [];
gdjs.winCode.GDboss_9595heart3Objects1= [];
gdjs.winCode.GDboss_9595heart3Objects2= [];
gdjs.winCode.GDboss_9595heart3Objects3= [];
gdjs.winCode.GDevile_9595guyObjects1= [];
gdjs.winCode.GDevile_9595guyObjects2= [];
gdjs.winCode.GDevile_9595guyObjects3= [];
gdjs.winCode.GDguy_9595sprite2Objects1= [];
gdjs.winCode.GDguy_9595sprite2Objects2= [];
gdjs.winCode.GDguy_9595sprite2Objects3= [];
gdjs.winCode.GDguy_9595sprite_9595clone2Objects1= [];
gdjs.winCode.GDguy_9595sprite_9595clone2Objects2= [];
gdjs.winCode.GDguy_9595sprite_9595clone2Objects3= [];


gdjs.winCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("BlackDecoratedButton"), gdjs.winCode.GDBlackDecoratedButtonObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.winCode.GDBlackDecoratedButtonObjects2.length;i<l;++i) {
    if ( gdjs.winCode.GDBlackDecoratedButtonObjects2[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.winCode.GDBlackDecoratedButtonObjects2[k] = gdjs.winCode.GDBlackDecoratedButtonObjects2[i];
        ++k;
    }
}
gdjs.winCode.GDBlackDecoratedButtonObjects2.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 1", false);
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("level1timedisplay"), gdjs.winCode.GDlevel1timedisplayObjects2);
gdjs.copyArray(runtimeScene.getObjects("scoreboard"), gdjs.winCode.GDscoreboardObjects2);
{for(var i = 0, len = gdjs.winCode.GDlevel1timedisplayObjects2.length ;i < len;++i) {
    gdjs.winCode.GDlevel1timedisplayObjects2[i].getBehavior("Text").setText("level 1 time:" + gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(1).getAsNumber()));
}
}
{for(var i = 0, len = gdjs.winCode.GDscoreboardObjects2.length ;i < len;++i) {
    gdjs.winCode.GDscoreboardObjects2[i].getBehavior("Text").setText("level 1 score: " + gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber()));
}
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.winCode.eventsList1 = function(runtimeScene) {

{


gdjs.winCode.eventsList0(runtimeScene);
}


};

gdjs.winCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.winCode.GDYOU_9595WIN_9595TEXTObjects1.length = 0;
gdjs.winCode.GDYOU_9595WIN_9595TEXTObjects2.length = 0;
gdjs.winCode.GDYOU_9595WIN_9595TEXTObjects3.length = 0;
gdjs.winCode.GDBlackDecoratedButtonObjects1.length = 0;
gdjs.winCode.GDBlackDecoratedButtonObjects2.length = 0;
gdjs.winCode.GDBlackDecoratedButtonObjects3.length = 0;
gdjs.winCode.GDlevel1timedisplayObjects1.length = 0;
gdjs.winCode.GDlevel1timedisplayObjects2.length = 0;
gdjs.winCode.GDlevel1timedisplayObjects3.length = 0;
gdjs.winCode.GDBlackDecoratedButton2Objects1.length = 0;
gdjs.winCode.GDBlackDecoratedButton2Objects2.length = 0;
gdjs.winCode.GDBlackDecoratedButton2Objects3.length = 0;
gdjs.winCode.GDscoreboardObjects1.length = 0;
gdjs.winCode.GDscoreboardObjects2.length = 0;
gdjs.winCode.GDscoreboardObjects3.length = 0;
gdjs.winCode.GDhearts_9595lifeObjects1.length = 0;
gdjs.winCode.GDhearts_9595lifeObjects2.length = 0;
gdjs.winCode.GDhearts_9595lifeObjects3.length = 0;
gdjs.winCode.GDhearts_9595life2Objects1.length = 0;
gdjs.winCode.GDhearts_9595life2Objects2.length = 0;
gdjs.winCode.GDhearts_9595life2Objects3.length = 0;
gdjs.winCode.GDhearts_9595life3Objects1.length = 0;
gdjs.winCode.GDhearts_9595life3Objects2.length = 0;
gdjs.winCode.GDhearts_9595life3Objects3.length = 0;
gdjs.winCode.GDball_9595guyObjects1.length = 0;
gdjs.winCode.GDball_9595guyObjects2.length = 0;
gdjs.winCode.GDball_9595guyObjects3.length = 0;
gdjs.winCode.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.winCode.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.winCode.GDguy_9595sprite_9595cloneObjects3.length = 0;
gdjs.winCode.GDguy_9595spriteObjects1.length = 0;
gdjs.winCode.GDguy_9595spriteObjects2.length = 0;
gdjs.winCode.GDguy_9595spriteObjects3.length = 0;
gdjs.winCode.GDtimekeeperObjects1.length = 0;
gdjs.winCode.GDtimekeeperObjects2.length = 0;
gdjs.winCode.GDtimekeeperObjects3.length = 0;
gdjs.winCode.GDdeathblockObjects1.length = 0;
gdjs.winCode.GDdeathblockObjects2.length = 0;
gdjs.winCode.GDdeathblockObjects3.length = 0;
gdjs.winCode.GDkey2Objects1.length = 0;
gdjs.winCode.GDkey2Objects2.length = 0;
gdjs.winCode.GDkey2Objects3.length = 0;
gdjs.winCode.GDscoreboardObjects1.length = 0;
gdjs.winCode.GDscoreboardObjects2.length = 0;
gdjs.winCode.GDscoreboardObjects3.length = 0;
gdjs.winCode.GDdoorObjects1.length = 0;
gdjs.winCode.GDdoorObjects2.length = 0;
gdjs.winCode.GDdoorObjects3.length = 0;
gdjs.winCode.GDno_9595keyObjects1.length = 0;
gdjs.winCode.GDno_9595keyObjects2.length = 0;
gdjs.winCode.GDno_9595keyObjects3.length = 0;
gdjs.winCode.GDcoinObjects1.length = 0;
gdjs.winCode.GDcoinObjects2.length = 0;
gdjs.winCode.GDcoinObjects3.length = 0;
gdjs.winCode.GDplatform_9595viruseObjects1.length = 0;
gdjs.winCode.GDplatform_9595viruseObjects2.length = 0;
gdjs.winCode.GDplatform_9595viruseObjects3.length = 0;
gdjs.winCode.GDboss_9595heartObjects1.length = 0;
gdjs.winCode.GDboss_9595heartObjects2.length = 0;
gdjs.winCode.GDboss_9595heartObjects3.length = 0;
gdjs.winCode.GDboss_9595heart2Objects1.length = 0;
gdjs.winCode.GDboss_9595heart2Objects2.length = 0;
gdjs.winCode.GDboss_9595heart2Objects3.length = 0;
gdjs.winCode.GDboss_9595heart3Objects1.length = 0;
gdjs.winCode.GDboss_9595heart3Objects2.length = 0;
gdjs.winCode.GDboss_9595heart3Objects3.length = 0;
gdjs.winCode.GDevile_9595guyObjects1.length = 0;
gdjs.winCode.GDevile_9595guyObjects2.length = 0;
gdjs.winCode.GDevile_9595guyObjects3.length = 0;
gdjs.winCode.GDguy_9595sprite2Objects1.length = 0;
gdjs.winCode.GDguy_9595sprite2Objects2.length = 0;
gdjs.winCode.GDguy_9595sprite2Objects3.length = 0;
gdjs.winCode.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.winCode.GDguy_9595sprite_9595clone2Objects2.length = 0;
gdjs.winCode.GDguy_9595sprite_9595clone2Objects3.length = 0;

gdjs.winCode.eventsList1(runtimeScene);
gdjs.winCode.GDYOU_9595WIN_9595TEXTObjects1.length = 0;
gdjs.winCode.GDYOU_9595WIN_9595TEXTObjects2.length = 0;
gdjs.winCode.GDYOU_9595WIN_9595TEXTObjects3.length = 0;
gdjs.winCode.GDBlackDecoratedButtonObjects1.length = 0;
gdjs.winCode.GDBlackDecoratedButtonObjects2.length = 0;
gdjs.winCode.GDBlackDecoratedButtonObjects3.length = 0;
gdjs.winCode.GDlevel1timedisplayObjects1.length = 0;
gdjs.winCode.GDlevel1timedisplayObjects2.length = 0;
gdjs.winCode.GDlevel1timedisplayObjects3.length = 0;
gdjs.winCode.GDBlackDecoratedButton2Objects1.length = 0;
gdjs.winCode.GDBlackDecoratedButton2Objects2.length = 0;
gdjs.winCode.GDBlackDecoratedButton2Objects3.length = 0;
gdjs.winCode.GDscoreboardObjects1.length = 0;
gdjs.winCode.GDscoreboardObjects2.length = 0;
gdjs.winCode.GDscoreboardObjects3.length = 0;
gdjs.winCode.GDhearts_9595lifeObjects1.length = 0;
gdjs.winCode.GDhearts_9595lifeObjects2.length = 0;
gdjs.winCode.GDhearts_9595lifeObjects3.length = 0;
gdjs.winCode.GDhearts_9595life2Objects1.length = 0;
gdjs.winCode.GDhearts_9595life2Objects2.length = 0;
gdjs.winCode.GDhearts_9595life2Objects3.length = 0;
gdjs.winCode.GDhearts_9595life3Objects1.length = 0;
gdjs.winCode.GDhearts_9595life3Objects2.length = 0;
gdjs.winCode.GDhearts_9595life3Objects3.length = 0;
gdjs.winCode.GDball_9595guyObjects1.length = 0;
gdjs.winCode.GDball_9595guyObjects2.length = 0;
gdjs.winCode.GDball_9595guyObjects3.length = 0;
gdjs.winCode.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.winCode.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.winCode.GDguy_9595sprite_9595cloneObjects3.length = 0;
gdjs.winCode.GDguy_9595spriteObjects1.length = 0;
gdjs.winCode.GDguy_9595spriteObjects2.length = 0;
gdjs.winCode.GDguy_9595spriteObjects3.length = 0;
gdjs.winCode.GDtimekeeperObjects1.length = 0;
gdjs.winCode.GDtimekeeperObjects2.length = 0;
gdjs.winCode.GDtimekeeperObjects3.length = 0;
gdjs.winCode.GDdeathblockObjects1.length = 0;
gdjs.winCode.GDdeathblockObjects2.length = 0;
gdjs.winCode.GDdeathblockObjects3.length = 0;
gdjs.winCode.GDkey2Objects1.length = 0;
gdjs.winCode.GDkey2Objects2.length = 0;
gdjs.winCode.GDkey2Objects3.length = 0;
gdjs.winCode.GDscoreboardObjects1.length = 0;
gdjs.winCode.GDscoreboardObjects2.length = 0;
gdjs.winCode.GDscoreboardObjects3.length = 0;
gdjs.winCode.GDdoorObjects1.length = 0;
gdjs.winCode.GDdoorObjects2.length = 0;
gdjs.winCode.GDdoorObjects3.length = 0;
gdjs.winCode.GDno_9595keyObjects1.length = 0;
gdjs.winCode.GDno_9595keyObjects2.length = 0;
gdjs.winCode.GDno_9595keyObjects3.length = 0;
gdjs.winCode.GDcoinObjects1.length = 0;
gdjs.winCode.GDcoinObjects2.length = 0;
gdjs.winCode.GDcoinObjects3.length = 0;
gdjs.winCode.GDplatform_9595viruseObjects1.length = 0;
gdjs.winCode.GDplatform_9595viruseObjects2.length = 0;
gdjs.winCode.GDplatform_9595viruseObjects3.length = 0;
gdjs.winCode.GDboss_9595heartObjects1.length = 0;
gdjs.winCode.GDboss_9595heartObjects2.length = 0;
gdjs.winCode.GDboss_9595heartObjects3.length = 0;
gdjs.winCode.GDboss_9595heart2Objects1.length = 0;
gdjs.winCode.GDboss_9595heart2Objects2.length = 0;
gdjs.winCode.GDboss_9595heart2Objects3.length = 0;
gdjs.winCode.GDboss_9595heart3Objects1.length = 0;
gdjs.winCode.GDboss_9595heart3Objects2.length = 0;
gdjs.winCode.GDboss_9595heart3Objects3.length = 0;
gdjs.winCode.GDevile_9595guyObjects1.length = 0;
gdjs.winCode.GDevile_9595guyObjects2.length = 0;
gdjs.winCode.GDevile_9595guyObjects3.length = 0;
gdjs.winCode.GDguy_9595sprite2Objects1.length = 0;
gdjs.winCode.GDguy_9595sprite2Objects2.length = 0;
gdjs.winCode.GDguy_9595sprite2Objects3.length = 0;
gdjs.winCode.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.winCode.GDguy_9595sprite_9595clone2Objects2.length = 0;
gdjs.winCode.GDguy_9595sprite_9595clone2Objects3.length = 0;


return;

}

gdjs['winCode'] = gdjs.winCode;
