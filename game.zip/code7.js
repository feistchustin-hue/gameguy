gdjs.explosionCode = {};
gdjs.explosionCode.localVariables = [];
gdjs.explosionCode.idToCallbackMap = new Map();
gdjs.explosionCode.GDNewSpriteObjects1= [];
gdjs.explosionCode.GDNewSpriteObjects2= [];
gdjs.explosionCode.GDhearts_9595lifeObjects1= [];
gdjs.explosionCode.GDhearts_9595lifeObjects2= [];
gdjs.explosionCode.GDhearts_9595life2Objects1= [];
gdjs.explosionCode.GDhearts_9595life2Objects2= [];
gdjs.explosionCode.GDhearts_9595life3Objects1= [];
gdjs.explosionCode.GDhearts_9595life3Objects2= [];
gdjs.explosionCode.GDball_9595guyObjects1= [];
gdjs.explosionCode.GDball_9595guyObjects2= [];
gdjs.explosionCode.GDguy_9595sprite_9595cloneObjects1= [];
gdjs.explosionCode.GDguy_9595sprite_9595cloneObjects2= [];
gdjs.explosionCode.GDguy_9595spriteObjects1= [];
gdjs.explosionCode.GDguy_9595spriteObjects2= [];
gdjs.explosionCode.GDtimekeeperObjects1= [];
gdjs.explosionCode.GDtimekeeperObjects2= [];
gdjs.explosionCode.GDdeathblockObjects1= [];
gdjs.explosionCode.GDdeathblockObjects2= [];
gdjs.explosionCode.GDkey2Objects1= [];
gdjs.explosionCode.GDkey2Objects2= [];
gdjs.explosionCode.GDscoreboardObjects1= [];
gdjs.explosionCode.GDscoreboardObjects2= [];
gdjs.explosionCode.GDdoorObjects1= [];
gdjs.explosionCode.GDdoorObjects2= [];
gdjs.explosionCode.GDno_9595keyObjects1= [];
gdjs.explosionCode.GDno_9595keyObjects2= [];
gdjs.explosionCode.GDcoinObjects1= [];
gdjs.explosionCode.GDcoinObjects2= [];
gdjs.explosionCode.GDplatform_9595viruseObjects1= [];
gdjs.explosionCode.GDplatform_9595viruseObjects2= [];
gdjs.explosionCode.GDboss_9595heartObjects1= [];
gdjs.explosionCode.GDboss_9595heartObjects2= [];
gdjs.explosionCode.GDboss_9595heart2Objects1= [];
gdjs.explosionCode.GDboss_9595heart2Objects2= [];
gdjs.explosionCode.GDboss_9595heart3Objects1= [];
gdjs.explosionCode.GDboss_9595heart3Objects2= [];
gdjs.explosionCode.GDevile_9595guyObjects1= [];
gdjs.explosionCode.GDevile_9595guyObjects2= [];
gdjs.explosionCode.GDguy_9595sprite2Objects1= [];
gdjs.explosionCode.GDguy_9595sprite2Objects2= [];
gdjs.explosionCode.GDguy_9595sprite_9595clone2Objects1= [];
gdjs.explosionCode.GDguy_9595sprite_9595clone2Objects2= [];


gdjs.explosionCode.asyncCallback16524548 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.explosionCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "after the battle", false);
}
gdjs.explosionCode.localVariables.length = 0;
}
gdjs.explosionCode.idToCallbackMap.set(16524548, gdjs.explosionCode.asyncCallback16524548);
gdjs.explosionCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.explosionCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.explosionCode.asyncCallback16524548(runtimeScene, asyncObjectsList)), 16524548, asyncObjectsList);
}
}

}


};gdjs.explosionCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.explosionCode.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.explosionCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.explosionCode.GDNewSpriteObjects1.length = 0;
gdjs.explosionCode.GDNewSpriteObjects2.length = 0;
gdjs.explosionCode.GDhearts_9595lifeObjects1.length = 0;
gdjs.explosionCode.GDhearts_9595lifeObjects2.length = 0;
gdjs.explosionCode.GDhearts_9595life2Objects1.length = 0;
gdjs.explosionCode.GDhearts_9595life2Objects2.length = 0;
gdjs.explosionCode.GDhearts_9595life3Objects1.length = 0;
gdjs.explosionCode.GDhearts_9595life3Objects2.length = 0;
gdjs.explosionCode.GDball_9595guyObjects1.length = 0;
gdjs.explosionCode.GDball_9595guyObjects2.length = 0;
gdjs.explosionCode.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.explosionCode.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.explosionCode.GDguy_9595spriteObjects1.length = 0;
gdjs.explosionCode.GDguy_9595spriteObjects2.length = 0;
gdjs.explosionCode.GDtimekeeperObjects1.length = 0;
gdjs.explosionCode.GDtimekeeperObjects2.length = 0;
gdjs.explosionCode.GDdeathblockObjects1.length = 0;
gdjs.explosionCode.GDdeathblockObjects2.length = 0;
gdjs.explosionCode.GDkey2Objects1.length = 0;
gdjs.explosionCode.GDkey2Objects2.length = 0;
gdjs.explosionCode.GDscoreboardObjects1.length = 0;
gdjs.explosionCode.GDscoreboardObjects2.length = 0;
gdjs.explosionCode.GDdoorObjects1.length = 0;
gdjs.explosionCode.GDdoorObjects2.length = 0;
gdjs.explosionCode.GDno_9595keyObjects1.length = 0;
gdjs.explosionCode.GDno_9595keyObjects2.length = 0;
gdjs.explosionCode.GDcoinObjects1.length = 0;
gdjs.explosionCode.GDcoinObjects2.length = 0;
gdjs.explosionCode.GDplatform_9595viruseObjects1.length = 0;
gdjs.explosionCode.GDplatform_9595viruseObjects2.length = 0;
gdjs.explosionCode.GDboss_9595heartObjects1.length = 0;
gdjs.explosionCode.GDboss_9595heartObjects2.length = 0;
gdjs.explosionCode.GDboss_9595heart2Objects1.length = 0;
gdjs.explosionCode.GDboss_9595heart2Objects2.length = 0;
gdjs.explosionCode.GDboss_9595heart3Objects1.length = 0;
gdjs.explosionCode.GDboss_9595heart3Objects2.length = 0;
gdjs.explosionCode.GDevile_9595guyObjects1.length = 0;
gdjs.explosionCode.GDevile_9595guyObjects2.length = 0;
gdjs.explosionCode.GDguy_9595sprite2Objects1.length = 0;
gdjs.explosionCode.GDguy_9595sprite2Objects2.length = 0;
gdjs.explosionCode.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.explosionCode.GDguy_9595sprite_9595clone2Objects2.length = 0;

gdjs.explosionCode.eventsList1(runtimeScene);
gdjs.explosionCode.GDNewSpriteObjects1.length = 0;
gdjs.explosionCode.GDNewSpriteObjects2.length = 0;
gdjs.explosionCode.GDhearts_9595lifeObjects1.length = 0;
gdjs.explosionCode.GDhearts_9595lifeObjects2.length = 0;
gdjs.explosionCode.GDhearts_9595life2Objects1.length = 0;
gdjs.explosionCode.GDhearts_9595life2Objects2.length = 0;
gdjs.explosionCode.GDhearts_9595life3Objects1.length = 0;
gdjs.explosionCode.GDhearts_9595life3Objects2.length = 0;
gdjs.explosionCode.GDball_9595guyObjects1.length = 0;
gdjs.explosionCode.GDball_9595guyObjects2.length = 0;
gdjs.explosionCode.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.explosionCode.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.explosionCode.GDguy_9595spriteObjects1.length = 0;
gdjs.explosionCode.GDguy_9595spriteObjects2.length = 0;
gdjs.explosionCode.GDtimekeeperObjects1.length = 0;
gdjs.explosionCode.GDtimekeeperObjects2.length = 0;
gdjs.explosionCode.GDdeathblockObjects1.length = 0;
gdjs.explosionCode.GDdeathblockObjects2.length = 0;
gdjs.explosionCode.GDkey2Objects1.length = 0;
gdjs.explosionCode.GDkey2Objects2.length = 0;
gdjs.explosionCode.GDscoreboardObjects1.length = 0;
gdjs.explosionCode.GDscoreboardObjects2.length = 0;
gdjs.explosionCode.GDdoorObjects1.length = 0;
gdjs.explosionCode.GDdoorObjects2.length = 0;
gdjs.explosionCode.GDno_9595keyObjects1.length = 0;
gdjs.explosionCode.GDno_9595keyObjects2.length = 0;
gdjs.explosionCode.GDcoinObjects1.length = 0;
gdjs.explosionCode.GDcoinObjects2.length = 0;
gdjs.explosionCode.GDplatform_9595viruseObjects1.length = 0;
gdjs.explosionCode.GDplatform_9595viruseObjects2.length = 0;
gdjs.explosionCode.GDboss_9595heartObjects1.length = 0;
gdjs.explosionCode.GDboss_9595heartObjects2.length = 0;
gdjs.explosionCode.GDboss_9595heart2Objects1.length = 0;
gdjs.explosionCode.GDboss_9595heart2Objects2.length = 0;
gdjs.explosionCode.GDboss_9595heart3Objects1.length = 0;
gdjs.explosionCode.GDboss_9595heart3Objects2.length = 0;
gdjs.explosionCode.GDevile_9595guyObjects1.length = 0;
gdjs.explosionCode.GDevile_9595guyObjects2.length = 0;
gdjs.explosionCode.GDguy_9595sprite2Objects1.length = 0;
gdjs.explosionCode.GDguy_9595sprite2Objects2.length = 0;
gdjs.explosionCode.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.explosionCode.GDguy_9595sprite_9595clone2Objects2.length = 0;


return;

}

gdjs['explosionCode'] = gdjs.explosionCode;
