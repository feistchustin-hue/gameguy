gdjs.after_32the_32battleCode = {};
gdjs.after_32the_32battleCode.localVariables = [];
gdjs.after_32the_32battleCode.idToCallbackMap = new Map();
gdjs.after_32the_32battleCode.GDNewTextObjects1= [];
gdjs.after_32the_32battleCode.GDNewTextObjects2= [];
gdjs.after_32the_32battleCode.GDTransparentButtonWithWhiteBlueBorderObjects1= [];
gdjs.after_32the_32battleCode.GDTransparentButtonWithWhiteBlueBorderObjects2= [];
gdjs.after_32the_32battleCode.GDhearts_9595lifeObjects1= [];
gdjs.after_32the_32battleCode.GDhearts_9595lifeObjects2= [];
gdjs.after_32the_32battleCode.GDhearts_9595life2Objects1= [];
gdjs.after_32the_32battleCode.GDhearts_9595life2Objects2= [];
gdjs.after_32the_32battleCode.GDhearts_9595life3Objects1= [];
gdjs.after_32the_32battleCode.GDhearts_9595life3Objects2= [];
gdjs.after_32the_32battleCode.GDball_9595guyObjects1= [];
gdjs.after_32the_32battleCode.GDball_9595guyObjects2= [];
gdjs.after_32the_32battleCode.GDguy_9595sprite_9595cloneObjects1= [];
gdjs.after_32the_32battleCode.GDguy_9595sprite_9595cloneObjects2= [];
gdjs.after_32the_32battleCode.GDguy_9595spriteObjects1= [];
gdjs.after_32the_32battleCode.GDguy_9595spriteObjects2= [];
gdjs.after_32the_32battleCode.GDtimekeeperObjects1= [];
gdjs.after_32the_32battleCode.GDtimekeeperObjects2= [];
gdjs.after_32the_32battleCode.GDdeathblockObjects1= [];
gdjs.after_32the_32battleCode.GDdeathblockObjects2= [];
gdjs.after_32the_32battleCode.GDkey2Objects1= [];
gdjs.after_32the_32battleCode.GDkey2Objects2= [];
gdjs.after_32the_32battleCode.GDscoreboardObjects1= [];
gdjs.after_32the_32battleCode.GDscoreboardObjects2= [];
gdjs.after_32the_32battleCode.GDdoorObjects1= [];
gdjs.after_32the_32battleCode.GDdoorObjects2= [];
gdjs.after_32the_32battleCode.GDno_9595keyObjects1= [];
gdjs.after_32the_32battleCode.GDno_9595keyObjects2= [];
gdjs.after_32the_32battleCode.GDcoinObjects1= [];
gdjs.after_32the_32battleCode.GDcoinObjects2= [];
gdjs.after_32the_32battleCode.GDplatform_9595viruseObjects1= [];
gdjs.after_32the_32battleCode.GDplatform_9595viruseObjects2= [];
gdjs.after_32the_32battleCode.GDboss_9595heartObjects1= [];
gdjs.after_32the_32battleCode.GDboss_9595heartObjects2= [];
gdjs.after_32the_32battleCode.GDboss_9595heart2Objects1= [];
gdjs.after_32the_32battleCode.GDboss_9595heart2Objects2= [];
gdjs.after_32the_32battleCode.GDboss_9595heart3Objects1= [];
gdjs.after_32the_32battleCode.GDboss_9595heart3Objects2= [];
gdjs.after_32the_32battleCode.GDevile_9595guyObjects1= [];
gdjs.after_32the_32battleCode.GDevile_9595guyObjects2= [];
gdjs.after_32the_32battleCode.GDguy_9595sprite2Objects1= [];
gdjs.after_32the_32battleCode.GDguy_9595sprite2Objects2= [];
gdjs.after_32the_32battleCode.GDguy_9595sprite_9595clone2Objects1= [];
gdjs.after_32the_32battleCode.GDguy_9595sprite_9595clone2Objects2= [];


gdjs.after_32the_32battleCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("TransparentButtonWithWhiteBlueBorder"), gdjs.after_32the_32battleCode.GDTransparentButtonWithWhiteBlueBorderObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.after_32the_32battleCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length;i<l;++i) {
    if ( gdjs.after_32the_32battleCode.GDTransparentButtonWithWhiteBlueBorderObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.after_32the_32battleCode.GDTransparentButtonWithWhiteBlueBorderObjects1[k] = gdjs.after_32the_32battleCode.GDTransparentButtonWithWhiteBlueBorderObjects1[i];
        ++k;
    }
}
gdjs.after_32the_32battleCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "final scene", false);
}
}

}


};

gdjs.after_32the_32battleCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.after_32the_32battleCode.GDNewTextObjects1.length = 0;
gdjs.after_32the_32battleCode.GDNewTextObjects2.length = 0;
gdjs.after_32the_32battleCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length = 0;
gdjs.after_32the_32battleCode.GDTransparentButtonWithWhiteBlueBorderObjects2.length = 0;
gdjs.after_32the_32battleCode.GDhearts_9595lifeObjects1.length = 0;
gdjs.after_32the_32battleCode.GDhearts_9595lifeObjects2.length = 0;
gdjs.after_32the_32battleCode.GDhearts_9595life2Objects1.length = 0;
gdjs.after_32the_32battleCode.GDhearts_9595life2Objects2.length = 0;
gdjs.after_32the_32battleCode.GDhearts_9595life3Objects1.length = 0;
gdjs.after_32the_32battleCode.GDhearts_9595life3Objects2.length = 0;
gdjs.after_32the_32battleCode.GDball_9595guyObjects1.length = 0;
gdjs.after_32the_32battleCode.GDball_9595guyObjects2.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595spriteObjects1.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595spriteObjects2.length = 0;
gdjs.after_32the_32battleCode.GDtimekeeperObjects1.length = 0;
gdjs.after_32the_32battleCode.GDtimekeeperObjects2.length = 0;
gdjs.after_32the_32battleCode.GDdeathblockObjects1.length = 0;
gdjs.after_32the_32battleCode.GDdeathblockObjects2.length = 0;
gdjs.after_32the_32battleCode.GDkey2Objects1.length = 0;
gdjs.after_32the_32battleCode.GDkey2Objects2.length = 0;
gdjs.after_32the_32battleCode.GDscoreboardObjects1.length = 0;
gdjs.after_32the_32battleCode.GDscoreboardObjects2.length = 0;
gdjs.after_32the_32battleCode.GDdoorObjects1.length = 0;
gdjs.after_32the_32battleCode.GDdoorObjects2.length = 0;
gdjs.after_32the_32battleCode.GDno_9595keyObjects1.length = 0;
gdjs.after_32the_32battleCode.GDno_9595keyObjects2.length = 0;
gdjs.after_32the_32battleCode.GDcoinObjects1.length = 0;
gdjs.after_32the_32battleCode.GDcoinObjects2.length = 0;
gdjs.after_32the_32battleCode.GDplatform_9595viruseObjects1.length = 0;
gdjs.after_32the_32battleCode.GDplatform_9595viruseObjects2.length = 0;
gdjs.after_32the_32battleCode.GDboss_9595heartObjects1.length = 0;
gdjs.after_32the_32battleCode.GDboss_9595heartObjects2.length = 0;
gdjs.after_32the_32battleCode.GDboss_9595heart2Objects1.length = 0;
gdjs.after_32the_32battleCode.GDboss_9595heart2Objects2.length = 0;
gdjs.after_32the_32battleCode.GDboss_9595heart3Objects1.length = 0;
gdjs.after_32the_32battleCode.GDboss_9595heart3Objects2.length = 0;
gdjs.after_32the_32battleCode.GDevile_9595guyObjects1.length = 0;
gdjs.after_32the_32battleCode.GDevile_9595guyObjects2.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595sprite2Objects1.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595sprite2Objects2.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595sprite_9595clone2Objects2.length = 0;

gdjs.after_32the_32battleCode.eventsList0(runtimeScene);
gdjs.after_32the_32battleCode.GDNewTextObjects1.length = 0;
gdjs.after_32the_32battleCode.GDNewTextObjects2.length = 0;
gdjs.after_32the_32battleCode.GDTransparentButtonWithWhiteBlueBorderObjects1.length = 0;
gdjs.after_32the_32battleCode.GDTransparentButtonWithWhiteBlueBorderObjects2.length = 0;
gdjs.after_32the_32battleCode.GDhearts_9595lifeObjects1.length = 0;
gdjs.after_32the_32battleCode.GDhearts_9595lifeObjects2.length = 0;
gdjs.after_32the_32battleCode.GDhearts_9595life2Objects1.length = 0;
gdjs.after_32the_32battleCode.GDhearts_9595life2Objects2.length = 0;
gdjs.after_32the_32battleCode.GDhearts_9595life3Objects1.length = 0;
gdjs.after_32the_32battleCode.GDhearts_9595life3Objects2.length = 0;
gdjs.after_32the_32battleCode.GDball_9595guyObjects1.length = 0;
gdjs.after_32the_32battleCode.GDball_9595guyObjects2.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595spriteObjects1.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595spriteObjects2.length = 0;
gdjs.after_32the_32battleCode.GDtimekeeperObjects1.length = 0;
gdjs.after_32the_32battleCode.GDtimekeeperObjects2.length = 0;
gdjs.after_32the_32battleCode.GDdeathblockObjects1.length = 0;
gdjs.after_32the_32battleCode.GDdeathblockObjects2.length = 0;
gdjs.after_32the_32battleCode.GDkey2Objects1.length = 0;
gdjs.after_32the_32battleCode.GDkey2Objects2.length = 0;
gdjs.after_32the_32battleCode.GDscoreboardObjects1.length = 0;
gdjs.after_32the_32battleCode.GDscoreboardObjects2.length = 0;
gdjs.after_32the_32battleCode.GDdoorObjects1.length = 0;
gdjs.after_32the_32battleCode.GDdoorObjects2.length = 0;
gdjs.after_32the_32battleCode.GDno_9595keyObjects1.length = 0;
gdjs.after_32the_32battleCode.GDno_9595keyObjects2.length = 0;
gdjs.after_32the_32battleCode.GDcoinObjects1.length = 0;
gdjs.after_32the_32battleCode.GDcoinObjects2.length = 0;
gdjs.after_32the_32battleCode.GDplatform_9595viruseObjects1.length = 0;
gdjs.after_32the_32battleCode.GDplatform_9595viruseObjects2.length = 0;
gdjs.after_32the_32battleCode.GDboss_9595heartObjects1.length = 0;
gdjs.after_32the_32battleCode.GDboss_9595heartObjects2.length = 0;
gdjs.after_32the_32battleCode.GDboss_9595heart2Objects1.length = 0;
gdjs.after_32the_32battleCode.GDboss_9595heart2Objects2.length = 0;
gdjs.after_32the_32battleCode.GDboss_9595heart3Objects1.length = 0;
gdjs.after_32the_32battleCode.GDboss_9595heart3Objects2.length = 0;
gdjs.after_32the_32battleCode.GDevile_9595guyObjects1.length = 0;
gdjs.after_32the_32battleCode.GDevile_9595guyObjects2.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595sprite2Objects1.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595sprite2Objects2.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.after_32the_32battleCode.GDguy_9595sprite_9595clone2Objects2.length = 0;


return;

}

gdjs['after_32the_32battleCode'] = gdjs.after_32the_32battleCode;
