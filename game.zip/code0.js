gdjs.level_321Code = {};
gdjs.level_321Code.localVariables = [];
gdjs.level_321Code.idToCallbackMap = new Map();
gdjs.level_321Code.GDNewTiledSpriteObjects1= [];
gdjs.level_321Code.GDNewTiledSpriteObjects2= [];
gdjs.level_321Code.GDNewTiledSpriteObjects3= [];
gdjs.level_321Code.GDguy_9595spriteObjects1= [];
gdjs.level_321Code.GDguy_9595spriteObjects2= [];
gdjs.level_321Code.GDguy_9595spriteObjects3= [];
gdjs.level_321Code.GDNewTiledSprite2Objects1= [];
gdjs.level_321Code.GDNewTiledSprite2Objects2= [];
gdjs.level_321Code.GDNewTiledSprite2Objects3= [];
gdjs.level_321Code.GDNewSprite2Objects1= [];
gdjs.level_321Code.GDNewSprite2Objects2= [];
gdjs.level_321Code.GDNewSprite2Objects3= [];
gdjs.level_321Code.GDparcour_9595platformObjects1= [];
gdjs.level_321Code.GDparcour_9595platformObjects2= [];
gdjs.level_321Code.GDparcour_9595platformObjects3= [];
gdjs.level_321Code.GDgoblinObjects1= [];
gdjs.level_321Code.GDgoblinObjects2= [];
gdjs.level_321Code.GDgoblinObjects3= [];
gdjs.level_321Code.GDkeyObjects1= [];
gdjs.level_321Code.GDkeyObjects2= [];
gdjs.level_321Code.GDkeyObjects3= [];
gdjs.level_321Code.GDbottomObjects1= [];
gdjs.level_321Code.GDbottomObjects2= [];
gdjs.level_321Code.GDbottomObjects3= [];
gdjs.level_321Code.GDhearts_9595lifeObjects1= [];
gdjs.level_321Code.GDhearts_9595lifeObjects2= [];
gdjs.level_321Code.GDhearts_9595lifeObjects3= [];
gdjs.level_321Code.GDhearts_9595life2Objects1= [];
gdjs.level_321Code.GDhearts_9595life2Objects2= [];
gdjs.level_321Code.GDhearts_9595life2Objects3= [];
gdjs.level_321Code.GDhearts_9595life3Objects1= [];
gdjs.level_321Code.GDhearts_9595life3Objects2= [];
gdjs.level_321Code.GDhearts_9595life3Objects3= [];
gdjs.level_321Code.GDball_9595guyObjects1= [];
gdjs.level_321Code.GDball_9595guyObjects2= [];
gdjs.level_321Code.GDball_9595guyObjects3= [];
gdjs.level_321Code.GDguy_9595sprite_9595cloneObjects1= [];
gdjs.level_321Code.GDguy_9595sprite_9595cloneObjects2= [];
gdjs.level_321Code.GDguy_9595sprite_9595cloneObjects3= [];
gdjs.level_321Code.GDguy_9595spriteObjects1= [];
gdjs.level_321Code.GDguy_9595spriteObjects2= [];
gdjs.level_321Code.GDguy_9595spriteObjects3= [];
gdjs.level_321Code.GDtimekeeperObjects1= [];
gdjs.level_321Code.GDtimekeeperObjects2= [];
gdjs.level_321Code.GDtimekeeperObjects3= [];
gdjs.level_321Code.GDdeathblockObjects1= [];
gdjs.level_321Code.GDdeathblockObjects2= [];
gdjs.level_321Code.GDdeathblockObjects3= [];
gdjs.level_321Code.GDkey2Objects1= [];
gdjs.level_321Code.GDkey2Objects2= [];
gdjs.level_321Code.GDkey2Objects3= [];
gdjs.level_321Code.GDscoreboardObjects1= [];
gdjs.level_321Code.GDscoreboardObjects2= [];
gdjs.level_321Code.GDscoreboardObjects3= [];
gdjs.level_321Code.GDdoorObjects1= [];
gdjs.level_321Code.GDdoorObjects2= [];
gdjs.level_321Code.GDdoorObjects3= [];
gdjs.level_321Code.GDno_9595keyObjects1= [];
gdjs.level_321Code.GDno_9595keyObjects2= [];
gdjs.level_321Code.GDno_9595keyObjects3= [];
gdjs.level_321Code.GDcoinObjects1= [];
gdjs.level_321Code.GDcoinObjects2= [];
gdjs.level_321Code.GDcoinObjects3= [];
gdjs.level_321Code.GDplatform_9595viruseObjects1= [];
gdjs.level_321Code.GDplatform_9595viruseObjects2= [];
gdjs.level_321Code.GDplatform_9595viruseObjects3= [];
gdjs.level_321Code.GDboss_9595heartObjects1= [];
gdjs.level_321Code.GDboss_9595heartObjects2= [];
gdjs.level_321Code.GDboss_9595heartObjects3= [];
gdjs.level_321Code.GDboss_9595heart2Objects1= [];
gdjs.level_321Code.GDboss_9595heart2Objects2= [];
gdjs.level_321Code.GDboss_9595heart2Objects3= [];
gdjs.level_321Code.GDboss_9595heart3Objects1= [];
gdjs.level_321Code.GDboss_9595heart3Objects2= [];
gdjs.level_321Code.GDboss_9595heart3Objects3= [];
gdjs.level_321Code.GDevile_9595guyObjects1= [];
gdjs.level_321Code.GDevile_9595guyObjects2= [];
gdjs.level_321Code.GDevile_9595guyObjects3= [];
gdjs.level_321Code.GDguy_9595sprite2Objects1= [];
gdjs.level_321Code.GDguy_9595sprite2Objects2= [];
gdjs.level_321Code.GDguy_9595sprite2Objects3= [];
gdjs.level_321Code.GDguy_9595sprite_9595clone2Objects1= [];
gdjs.level_321Code.GDguy_9595sprite_9595clone2Objects2= [];
gdjs.level_321Code.GDguy_9595sprite_9595clone2Objects3= [];


gdjs.level_321Code.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("scoreboard"), gdjs.level_321Code.GDscoreboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("timekeeper"), gdjs.level_321Code.GDtimekeeperObjects2);
{for(var i = 0, len = gdjs.level_321Code.GDscoreboardObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDscoreboardObjects2[i].getBehavior("Text").setText("coins: " + gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber()));
}
}
{for(var i = 0, len = gdjs.level_321Code.GDtimekeeperObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDtimekeeperObjects2[i].getBehavior("Text").setText("Time: " + gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "timelevel1"))));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("key"), gdjs.level_321Code.GDkeyObjects1);
{for(var i = 0, len = gdjs.level_321Code.GDkeyObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDkeyObjects1[i].hide();
}
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "timelevel1");
}
}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDguy_95959595spriteObjects2Objects = Hashtable.newFrom({"guy_sprite": gdjs.level_321Code.GDguy_9595spriteObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDgoblinObjects2Objects = Hashtable.newFrom({"goblin": gdjs.level_321Code.GDgoblinObjects2});
gdjs.level_321Code.asyncCallback16105244 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 1", false);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).sub(1);
}
gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.idToCallbackMap.set(16105244, gdjs.level_321Code.asyncCallback16105244);
gdjs.level_321Code.eventsList1 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(7), (runtimeScene) => (gdjs.level_321Code.asyncCallback16105244(runtimeScene, asyncObjectsList)), 16105244, asyncObjectsList);
}
}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDguy_95959595spriteObjects1Objects = Hashtable.newFrom({"guy_sprite": gdjs.level_321Code.GDguy_9595spriteObjects1});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDbottomObjects1Objects = Hashtable.newFrom({"bottom": gdjs.level_321Code.GDbottomObjects1});
gdjs.level_321Code.asyncCallback16107636 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_321Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 1", false);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).sub(1);
}
gdjs.level_321Code.localVariables.length = 0;
}
gdjs.level_321Code.idToCallbackMap.set(16107636, gdjs.level_321Code.asyncCallback16107636);
gdjs.level_321Code.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_321Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(7), (runtimeScene) => (gdjs.level_321Code.asyncCallback16107636(runtimeScene, asyncObjectsList)), 16107636, asyncObjectsList);
}
}

}


};gdjs.level_321Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("goblin"), gdjs.level_321Code.GDgoblinObjects2);
gdjs.copyArray(runtimeScene.getObjects("guy_sprite"), gdjs.level_321Code.GDguy_9595spriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDguy_95959595spriteObjects2Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDgoblinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16104500);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDguy_9595spriteObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDguy_9595spriteObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDguy_9595spriteObjects2[i].getBehavior("Animation").setAnimationName("death");
}
}

{ //Subevents
gdjs.level_321Code.eventsList1(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("bottom"), gdjs.level_321Code.GDbottomObjects1);
gdjs.copyArray(runtimeScene.getObjects("guy_sprite"), gdjs.level_321Code.GDguy_9595spriteObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDguy_95959595spriteObjects1Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDbottomObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16106628);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDguy_9595spriteObjects1 */
{for(var i = 0, len = gdjs.level_321Code.GDguy_9595spriteObjects1.length ;i < len;++i) {
    gdjs.level_321Code.GDguy_9595spriteObjects1[i].getBehavior("Animation").setAnimationName("death");
}
}

{ //Subevents
gdjs.level_321Code.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDguy_95959595spriteObjects2Objects = Hashtable.newFrom({"guy_sprite": gdjs.level_321Code.GDguy_9595spriteObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDcoinObjects2Objects = Hashtable.newFrom({"coin": gdjs.level_321Code.GDcoinObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDguy_95959595spriteObjects2Objects = Hashtable.newFrom({"guy_sprite": gdjs.level_321Code.GDguy_9595spriteObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDkeyObjects2Objects = Hashtable.newFrom({"key": gdjs.level_321Code.GDkeyObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDguy_95959595spriteObjects2Objects = Hashtable.newFrom({"guy_sprite": gdjs.level_321Code.GDguy_9595spriteObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDdoorObjects2Objects = Hashtable.newFrom({"door": gdjs.level_321Code.GDdoorObjects2});
gdjs.level_321Code.eventsList4 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
{
}

}


};gdjs.level_321Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("coin"), gdjs.level_321Code.GDcoinObjects2);
gdjs.copyArray(runtimeScene.getObjects("guy_sprite"), gdjs.level_321Code.GDguy_9595spriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDguy_95959595spriteObjects2Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDcoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDcoinObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}
{for(var i = 0, len = gdjs.level_321Code.GDcoinObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDcoinObjects2[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect", false, 100, 1);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("guy_sprite"), gdjs.level_321Code.GDguy_9595spriteObjects2);
gdjs.copyArray(runtimeScene.getObjects("key"), gdjs.level_321Code.GDkeyObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDguy_95959595spriteObjects2Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDkeyObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDkeyObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDkeyObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDkeyObjects2[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 100, 1);
}
{runtimeScene.getScene().getVariables().getFromIndex(0).setBoolean(true);
}
{for(var i = 0, len = gdjs.level_321Code.GDkeyObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDkeyObjects2[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("door"), gdjs.level_321Code.GDdoorObjects2);
gdjs.copyArray(runtimeScene.getObjects("guy_sprite"), gdjs.level_321Code.GDguy_9595spriteObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDguy_95959595spriteObjects2Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDdoorObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getScene().getVariables().getFromIndex(0).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber() >= 6);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDdoorObjects2 */
{for(var i = 0, len = gdjs.level_321Code.GDdoorObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDdoorObjects2[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 2", false);
}
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "timelevel1");
}
{runtimeScene.getGame().getVariables().getFromIndex(1).setNumber(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "timelevel1"));
}

{ //Subevents
gdjs.level_321Code.eventsList4(runtimeScene);} //End of subevents
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDguy_95959595spriteObjects2Objects = Hashtable.newFrom({"guy_sprite": gdjs.level_321Code.GDguy_9595spriteObjects2});
gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDhearts_95959595lifeObjects2Objects = Hashtable.newFrom({"hearts_life": gdjs.level_321Code.GDhearts_9595lifeObjects2});
gdjs.level_321Code.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() >= 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life"), gdjs.level_321Code.GDhearts_9595lifeObjects2);
{for(var i = 0, len = gdjs.level_321Code.GDhearts_9595lifeObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDhearts_9595lifeObjects2[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() >= 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life2"), gdjs.level_321Code.GDhearts_9595life2Objects2);
{for(var i = 0, len = gdjs.level_321Code.GDhearts_9595life2Objects2.length ;i < len;++i) {
    gdjs.level_321Code.GDhearts_9595life2Objects2[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() >= 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life3"), gdjs.level_321Code.GDhearts_9595life3Objects2);
{for(var i = 0, len = gdjs.level_321Code.GDhearts_9595life3Objects2.length ;i < len;++i) {
    gdjs.level_321Code.GDhearts_9595life3Objects2[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() < 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life"), gdjs.level_321Code.GDhearts_9595lifeObjects2);
{for(var i = 0, len = gdjs.level_321Code.GDhearts_9595lifeObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDhearts_9595lifeObjects2[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() < 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life2"), gdjs.level_321Code.GDhearts_9595life2Objects2);
{for(var i = 0, len = gdjs.level_321Code.GDhearts_9595life2Objects2.length ;i < len;++i) {
    gdjs.level_321Code.GDhearts_9595life2Objects2[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() < 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life3"), gdjs.level_321Code.GDhearts_9595life3Objects2);
{for(var i = 0, len = gdjs.level_321Code.GDhearts_9595life3Objects2.length ;i < len;++i) {
    gdjs.level_321Code.GDhearts_9595life3Objects2[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() == 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "game over", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("guy_sprite"), gdjs.level_321Code.GDguy_9595spriteObjects2);
gdjs.copyArray(runtimeScene.getObjects("hearts_life"), gdjs.level_321Code.GDhearts_9595lifeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDguy_95959595spriteObjects2Objects, gdjs.level_321Code.mapOfGDgdjs_9546level_9595321Code_9546GDhearts_95959595lifeObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level_321Code.GDhearts_9595lifeObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(4).add(1);
}
{for(var i = 0, len = gdjs.level_321Code.GDhearts_9595lifeObjects2.length ;i < len;++i) {
    gdjs.level_321Code.GDhearts_9595lifeObjects2[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() > 3);
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(4).sub(1);
}
}

}


};gdjs.level_321Code.eventsList7 = function(runtimeScene) {

{


gdjs.level_321Code.eventsList0(runtimeScene);
}


{


gdjs.level_321Code.eventsList3(runtimeScene);
}


{


gdjs.level_321Code.eventsList5(runtimeScene);
}


{


gdjs.level_321Code.eventsList6(runtimeScene);
}


};

gdjs.level_321Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.level_321Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.level_321Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.level_321Code.GDNewTiledSpriteObjects3.length = 0;
gdjs.level_321Code.GDguy_9595spriteObjects1.length = 0;
gdjs.level_321Code.GDguy_9595spriteObjects2.length = 0;
gdjs.level_321Code.GDguy_9595spriteObjects3.length = 0;
gdjs.level_321Code.GDNewTiledSprite2Objects1.length = 0;
gdjs.level_321Code.GDNewTiledSprite2Objects2.length = 0;
gdjs.level_321Code.GDNewTiledSprite2Objects3.length = 0;
gdjs.level_321Code.GDNewSprite2Objects1.length = 0;
gdjs.level_321Code.GDNewSprite2Objects2.length = 0;
gdjs.level_321Code.GDNewSprite2Objects3.length = 0;
gdjs.level_321Code.GDparcour_9595platformObjects1.length = 0;
gdjs.level_321Code.GDparcour_9595platformObjects2.length = 0;
gdjs.level_321Code.GDparcour_9595platformObjects3.length = 0;
gdjs.level_321Code.GDgoblinObjects1.length = 0;
gdjs.level_321Code.GDgoblinObjects2.length = 0;
gdjs.level_321Code.GDgoblinObjects3.length = 0;
gdjs.level_321Code.GDkeyObjects1.length = 0;
gdjs.level_321Code.GDkeyObjects2.length = 0;
gdjs.level_321Code.GDkeyObjects3.length = 0;
gdjs.level_321Code.GDbottomObjects1.length = 0;
gdjs.level_321Code.GDbottomObjects2.length = 0;
gdjs.level_321Code.GDbottomObjects3.length = 0;
gdjs.level_321Code.GDhearts_9595lifeObjects1.length = 0;
gdjs.level_321Code.GDhearts_9595lifeObjects2.length = 0;
gdjs.level_321Code.GDhearts_9595lifeObjects3.length = 0;
gdjs.level_321Code.GDhearts_9595life2Objects1.length = 0;
gdjs.level_321Code.GDhearts_9595life2Objects2.length = 0;
gdjs.level_321Code.GDhearts_9595life2Objects3.length = 0;
gdjs.level_321Code.GDhearts_9595life3Objects1.length = 0;
gdjs.level_321Code.GDhearts_9595life3Objects2.length = 0;
gdjs.level_321Code.GDhearts_9595life3Objects3.length = 0;
gdjs.level_321Code.GDball_9595guyObjects1.length = 0;
gdjs.level_321Code.GDball_9595guyObjects2.length = 0;
gdjs.level_321Code.GDball_9595guyObjects3.length = 0;
gdjs.level_321Code.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.level_321Code.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.level_321Code.GDguy_9595sprite_9595cloneObjects3.length = 0;
gdjs.level_321Code.GDguy_9595spriteObjects1.length = 0;
gdjs.level_321Code.GDguy_9595spriteObjects2.length = 0;
gdjs.level_321Code.GDguy_9595spriteObjects3.length = 0;
gdjs.level_321Code.GDtimekeeperObjects1.length = 0;
gdjs.level_321Code.GDtimekeeperObjects2.length = 0;
gdjs.level_321Code.GDtimekeeperObjects3.length = 0;
gdjs.level_321Code.GDdeathblockObjects1.length = 0;
gdjs.level_321Code.GDdeathblockObjects2.length = 0;
gdjs.level_321Code.GDdeathblockObjects3.length = 0;
gdjs.level_321Code.GDkey2Objects1.length = 0;
gdjs.level_321Code.GDkey2Objects2.length = 0;
gdjs.level_321Code.GDkey2Objects3.length = 0;
gdjs.level_321Code.GDscoreboardObjects1.length = 0;
gdjs.level_321Code.GDscoreboardObjects2.length = 0;
gdjs.level_321Code.GDscoreboardObjects3.length = 0;
gdjs.level_321Code.GDdoorObjects1.length = 0;
gdjs.level_321Code.GDdoorObjects2.length = 0;
gdjs.level_321Code.GDdoorObjects3.length = 0;
gdjs.level_321Code.GDno_9595keyObjects1.length = 0;
gdjs.level_321Code.GDno_9595keyObjects2.length = 0;
gdjs.level_321Code.GDno_9595keyObjects3.length = 0;
gdjs.level_321Code.GDcoinObjects1.length = 0;
gdjs.level_321Code.GDcoinObjects2.length = 0;
gdjs.level_321Code.GDcoinObjects3.length = 0;
gdjs.level_321Code.GDplatform_9595viruseObjects1.length = 0;
gdjs.level_321Code.GDplatform_9595viruseObjects2.length = 0;
gdjs.level_321Code.GDplatform_9595viruseObjects3.length = 0;
gdjs.level_321Code.GDboss_9595heartObjects1.length = 0;
gdjs.level_321Code.GDboss_9595heartObjects2.length = 0;
gdjs.level_321Code.GDboss_9595heartObjects3.length = 0;
gdjs.level_321Code.GDboss_9595heart2Objects1.length = 0;
gdjs.level_321Code.GDboss_9595heart2Objects2.length = 0;
gdjs.level_321Code.GDboss_9595heart2Objects3.length = 0;
gdjs.level_321Code.GDboss_9595heart3Objects1.length = 0;
gdjs.level_321Code.GDboss_9595heart3Objects2.length = 0;
gdjs.level_321Code.GDboss_9595heart3Objects3.length = 0;
gdjs.level_321Code.GDevile_9595guyObjects1.length = 0;
gdjs.level_321Code.GDevile_9595guyObjects2.length = 0;
gdjs.level_321Code.GDevile_9595guyObjects3.length = 0;
gdjs.level_321Code.GDguy_9595sprite2Objects1.length = 0;
gdjs.level_321Code.GDguy_9595sprite2Objects2.length = 0;
gdjs.level_321Code.GDguy_9595sprite2Objects3.length = 0;
gdjs.level_321Code.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.level_321Code.GDguy_9595sprite_9595clone2Objects2.length = 0;
gdjs.level_321Code.GDguy_9595sprite_9595clone2Objects3.length = 0;

gdjs.level_321Code.eventsList7(runtimeScene);
gdjs.level_321Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.level_321Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.level_321Code.GDNewTiledSpriteObjects3.length = 0;
gdjs.level_321Code.GDguy_9595spriteObjects1.length = 0;
gdjs.level_321Code.GDguy_9595spriteObjects2.length = 0;
gdjs.level_321Code.GDguy_9595spriteObjects3.length = 0;
gdjs.level_321Code.GDNewTiledSprite2Objects1.length = 0;
gdjs.level_321Code.GDNewTiledSprite2Objects2.length = 0;
gdjs.level_321Code.GDNewTiledSprite2Objects3.length = 0;
gdjs.level_321Code.GDNewSprite2Objects1.length = 0;
gdjs.level_321Code.GDNewSprite2Objects2.length = 0;
gdjs.level_321Code.GDNewSprite2Objects3.length = 0;
gdjs.level_321Code.GDparcour_9595platformObjects1.length = 0;
gdjs.level_321Code.GDparcour_9595platformObjects2.length = 0;
gdjs.level_321Code.GDparcour_9595platformObjects3.length = 0;
gdjs.level_321Code.GDgoblinObjects1.length = 0;
gdjs.level_321Code.GDgoblinObjects2.length = 0;
gdjs.level_321Code.GDgoblinObjects3.length = 0;
gdjs.level_321Code.GDkeyObjects1.length = 0;
gdjs.level_321Code.GDkeyObjects2.length = 0;
gdjs.level_321Code.GDkeyObjects3.length = 0;
gdjs.level_321Code.GDbottomObjects1.length = 0;
gdjs.level_321Code.GDbottomObjects2.length = 0;
gdjs.level_321Code.GDbottomObjects3.length = 0;
gdjs.level_321Code.GDhearts_9595lifeObjects1.length = 0;
gdjs.level_321Code.GDhearts_9595lifeObjects2.length = 0;
gdjs.level_321Code.GDhearts_9595lifeObjects3.length = 0;
gdjs.level_321Code.GDhearts_9595life2Objects1.length = 0;
gdjs.level_321Code.GDhearts_9595life2Objects2.length = 0;
gdjs.level_321Code.GDhearts_9595life2Objects3.length = 0;
gdjs.level_321Code.GDhearts_9595life3Objects1.length = 0;
gdjs.level_321Code.GDhearts_9595life3Objects2.length = 0;
gdjs.level_321Code.GDhearts_9595life3Objects3.length = 0;
gdjs.level_321Code.GDball_9595guyObjects1.length = 0;
gdjs.level_321Code.GDball_9595guyObjects2.length = 0;
gdjs.level_321Code.GDball_9595guyObjects3.length = 0;
gdjs.level_321Code.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.level_321Code.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.level_321Code.GDguy_9595sprite_9595cloneObjects3.length = 0;
gdjs.level_321Code.GDguy_9595spriteObjects1.length = 0;
gdjs.level_321Code.GDguy_9595spriteObjects2.length = 0;
gdjs.level_321Code.GDguy_9595spriteObjects3.length = 0;
gdjs.level_321Code.GDtimekeeperObjects1.length = 0;
gdjs.level_321Code.GDtimekeeperObjects2.length = 0;
gdjs.level_321Code.GDtimekeeperObjects3.length = 0;
gdjs.level_321Code.GDdeathblockObjects1.length = 0;
gdjs.level_321Code.GDdeathblockObjects2.length = 0;
gdjs.level_321Code.GDdeathblockObjects3.length = 0;
gdjs.level_321Code.GDkey2Objects1.length = 0;
gdjs.level_321Code.GDkey2Objects2.length = 0;
gdjs.level_321Code.GDkey2Objects3.length = 0;
gdjs.level_321Code.GDscoreboardObjects1.length = 0;
gdjs.level_321Code.GDscoreboardObjects2.length = 0;
gdjs.level_321Code.GDscoreboardObjects3.length = 0;
gdjs.level_321Code.GDdoorObjects1.length = 0;
gdjs.level_321Code.GDdoorObjects2.length = 0;
gdjs.level_321Code.GDdoorObjects3.length = 0;
gdjs.level_321Code.GDno_9595keyObjects1.length = 0;
gdjs.level_321Code.GDno_9595keyObjects2.length = 0;
gdjs.level_321Code.GDno_9595keyObjects3.length = 0;
gdjs.level_321Code.GDcoinObjects1.length = 0;
gdjs.level_321Code.GDcoinObjects2.length = 0;
gdjs.level_321Code.GDcoinObjects3.length = 0;
gdjs.level_321Code.GDplatform_9595viruseObjects1.length = 0;
gdjs.level_321Code.GDplatform_9595viruseObjects2.length = 0;
gdjs.level_321Code.GDplatform_9595viruseObjects3.length = 0;
gdjs.level_321Code.GDboss_9595heartObjects1.length = 0;
gdjs.level_321Code.GDboss_9595heartObjects2.length = 0;
gdjs.level_321Code.GDboss_9595heartObjects3.length = 0;
gdjs.level_321Code.GDboss_9595heart2Objects1.length = 0;
gdjs.level_321Code.GDboss_9595heart2Objects2.length = 0;
gdjs.level_321Code.GDboss_9595heart2Objects3.length = 0;
gdjs.level_321Code.GDboss_9595heart3Objects1.length = 0;
gdjs.level_321Code.GDboss_9595heart3Objects2.length = 0;
gdjs.level_321Code.GDboss_9595heart3Objects3.length = 0;
gdjs.level_321Code.GDevile_9595guyObjects1.length = 0;
gdjs.level_321Code.GDevile_9595guyObjects2.length = 0;
gdjs.level_321Code.GDevile_9595guyObjects3.length = 0;
gdjs.level_321Code.GDguy_9595sprite2Objects1.length = 0;
gdjs.level_321Code.GDguy_9595sprite2Objects2.length = 0;
gdjs.level_321Code.GDguy_9595sprite2Objects3.length = 0;
gdjs.level_321Code.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.level_321Code.GDguy_9595sprite_9595clone2Objects2.length = 0;
gdjs.level_321Code.GDguy_9595sprite_9595clone2Objects3.length = 0;


return;

}

gdjs['level_321Code'] = gdjs.level_321Code;
