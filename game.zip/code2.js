gdjs.level_322Code = {};
gdjs.level_322Code.localVariables = [];
gdjs.level_322Code.idToCallbackMap = new Map();
gdjs.level_322Code.GDblockObjects1= [];
gdjs.level_322Code.GDblockObjects2= [];
gdjs.level_322Code.GDblockObjects3= [];
gdjs.level_322Code.GDblockObjects4= [];
gdjs.level_322Code.GDgroundObjects1= [];
gdjs.level_322Code.GDgroundObjects2= [];
gdjs.level_322Code.GDgroundObjects3= [];
gdjs.level_322Code.GDgroundObjects4= [];
gdjs.level_322Code.GDgood_9595guy_9595sprite_9595textObjects1= [];
gdjs.level_322Code.GDgood_9595guy_9595sprite_9595textObjects2= [];
gdjs.level_322Code.GDgood_9595guy_9595sprite_9595textObjects3= [];
gdjs.level_322Code.GDgood_9595guy_9595sprite_9595textObjects4= [];
gdjs.level_322Code.GDbackground_9595tutorialObjects1= [];
gdjs.level_322Code.GDbackground_9595tutorialObjects2= [];
gdjs.level_322Code.GDbackground_9595tutorialObjects3= [];
gdjs.level_322Code.GDbackground_9595tutorialObjects4= [];
gdjs.level_322Code.GDghost_9595blockObjects1= [];
gdjs.level_322Code.GDghost_9595blockObjects2= [];
gdjs.level_322Code.GDghost_9595blockObjects3= [];
gdjs.level_322Code.GDghost_9595blockObjects4= [];
gdjs.level_322Code.GDbottomObjects1= [];
gdjs.level_322Code.GDbottomObjects2= [];
gdjs.level_322Code.GDbottomObjects3= [];
gdjs.level_322Code.GDbottomObjects4= [];
gdjs.level_322Code.GDhearts_9595lifeObjects1= [];
gdjs.level_322Code.GDhearts_9595lifeObjects2= [];
gdjs.level_322Code.GDhearts_9595lifeObjects3= [];
gdjs.level_322Code.GDhearts_9595lifeObjects4= [];
gdjs.level_322Code.GDhearts_9595life2Objects1= [];
gdjs.level_322Code.GDhearts_9595life2Objects2= [];
gdjs.level_322Code.GDhearts_9595life2Objects3= [];
gdjs.level_322Code.GDhearts_9595life2Objects4= [];
gdjs.level_322Code.GDhearts_9595life3Objects1= [];
gdjs.level_322Code.GDhearts_9595life3Objects2= [];
gdjs.level_322Code.GDhearts_9595life3Objects3= [];
gdjs.level_322Code.GDhearts_9595life3Objects4= [];
gdjs.level_322Code.GDball_9595guyObjects1= [];
gdjs.level_322Code.GDball_9595guyObjects2= [];
gdjs.level_322Code.GDball_9595guyObjects3= [];
gdjs.level_322Code.GDball_9595guyObjects4= [];
gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects1= [];
gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects2= [];
gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects3= [];
gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects4= [];
gdjs.level_322Code.GDguy_9595spriteObjects1= [];
gdjs.level_322Code.GDguy_9595spriteObjects2= [];
gdjs.level_322Code.GDguy_9595spriteObjects3= [];
gdjs.level_322Code.GDguy_9595spriteObjects4= [];
gdjs.level_322Code.GDtimekeeperObjects1= [];
gdjs.level_322Code.GDtimekeeperObjects2= [];
gdjs.level_322Code.GDtimekeeperObjects3= [];
gdjs.level_322Code.GDtimekeeperObjects4= [];
gdjs.level_322Code.GDdeathblockObjects1= [];
gdjs.level_322Code.GDdeathblockObjects2= [];
gdjs.level_322Code.GDdeathblockObjects3= [];
gdjs.level_322Code.GDdeathblockObjects4= [];
gdjs.level_322Code.GDkey2Objects1= [];
gdjs.level_322Code.GDkey2Objects2= [];
gdjs.level_322Code.GDkey2Objects3= [];
gdjs.level_322Code.GDkey2Objects4= [];
gdjs.level_322Code.GDscoreboardObjects1= [];
gdjs.level_322Code.GDscoreboardObjects2= [];
gdjs.level_322Code.GDscoreboardObjects3= [];
gdjs.level_322Code.GDscoreboardObjects4= [];
gdjs.level_322Code.GDdoorObjects1= [];
gdjs.level_322Code.GDdoorObjects2= [];
gdjs.level_322Code.GDdoorObjects3= [];
gdjs.level_322Code.GDdoorObjects4= [];
gdjs.level_322Code.GDno_9595keyObjects1= [];
gdjs.level_322Code.GDno_9595keyObjects2= [];
gdjs.level_322Code.GDno_9595keyObjects3= [];
gdjs.level_322Code.GDno_9595keyObjects4= [];
gdjs.level_322Code.GDcoinObjects1= [];
gdjs.level_322Code.GDcoinObjects2= [];
gdjs.level_322Code.GDcoinObjects3= [];
gdjs.level_322Code.GDcoinObjects4= [];
gdjs.level_322Code.GDplatform_9595viruseObjects1= [];
gdjs.level_322Code.GDplatform_9595viruseObjects2= [];
gdjs.level_322Code.GDplatform_9595viruseObjects3= [];
gdjs.level_322Code.GDplatform_9595viruseObjects4= [];
gdjs.level_322Code.GDboss_9595heartObjects1= [];
gdjs.level_322Code.GDboss_9595heartObjects2= [];
gdjs.level_322Code.GDboss_9595heartObjects3= [];
gdjs.level_322Code.GDboss_9595heartObjects4= [];
gdjs.level_322Code.GDboss_9595heart2Objects1= [];
gdjs.level_322Code.GDboss_9595heart2Objects2= [];
gdjs.level_322Code.GDboss_9595heart2Objects3= [];
gdjs.level_322Code.GDboss_9595heart2Objects4= [];
gdjs.level_322Code.GDboss_9595heart3Objects1= [];
gdjs.level_322Code.GDboss_9595heart3Objects2= [];
gdjs.level_322Code.GDboss_9595heart3Objects3= [];
gdjs.level_322Code.GDboss_9595heart3Objects4= [];
gdjs.level_322Code.GDevile_9595guyObjects1= [];
gdjs.level_322Code.GDevile_9595guyObjects2= [];
gdjs.level_322Code.GDevile_9595guyObjects3= [];
gdjs.level_322Code.GDevile_9595guyObjects4= [];
gdjs.level_322Code.GDguy_9595sprite2Objects1= [];
gdjs.level_322Code.GDguy_9595sprite2Objects2= [];
gdjs.level_322Code.GDguy_9595sprite2Objects3= [];
gdjs.level_322Code.GDguy_9595sprite2Objects4= [];
gdjs.level_322Code.GDguy_9595sprite_9595clone2Objects1= [];
gdjs.level_322Code.GDguy_9595sprite_9595clone2Objects2= [];
gdjs.level_322Code.GDguy_9595sprite_9595clone2Objects3= [];
gdjs.level_322Code.GDguy_9595sprite_9595clone2Objects4= [];


gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects2Objects = Hashtable.newFrom({"ball_guy": gdjs.level_322Code.GDball_9595guyObjects2});
gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDdeathblockObjects2Objects = Hashtable.newFrom({"deathblock": gdjs.level_322Code.GDdeathblockObjects2});
gdjs.level_322Code.asyncCallback16237108 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_322Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 2", false);
}
gdjs.level_322Code.localVariables.length = 0;
}
gdjs.level_322Code.idToCallbackMap.set(16237108, gdjs.level_322Code.asyncCallback16237108);
gdjs.level_322Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_322Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.level_322Code.asyncCallback16237108(runtimeScene, asyncObjectsList)), 16237108, asyncObjectsList);
}
}

}


};gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects2Objects = Hashtable.newFrom({"ball_guy": gdjs.level_322Code.GDball_9595guyObjects2});
gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDkey2Objects2Objects = Hashtable.newFrom({"key2": gdjs.level_322Code.GDkey2Objects2});
gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects2Objects = Hashtable.newFrom({"ball_guy": gdjs.level_322Code.GDball_9595guyObjects2});
gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDdoorObjects2Objects = Hashtable.newFrom({"door": gdjs.level_322Code.GDdoorObjects2});
gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects2Objects = Hashtable.newFrom({"ball_guy": gdjs.level_322Code.GDball_9595guyObjects2});
gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDhearts_95959595lifeObjects2Objects = Hashtable.newFrom({"hearts_life": gdjs.level_322Code.GDhearts_9595lifeObjects2});
gdjs.level_322Code.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() >= 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life"), gdjs.level_322Code.GDhearts_9595lifeObjects3);
{for(var i = 0, len = gdjs.level_322Code.GDhearts_9595lifeObjects3.length ;i < len;++i) {
    gdjs.level_322Code.GDhearts_9595lifeObjects3[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() >= 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life2"), gdjs.level_322Code.GDhearts_9595life2Objects3);
{for(var i = 0, len = gdjs.level_322Code.GDhearts_9595life2Objects3.length ;i < len;++i) {
    gdjs.level_322Code.GDhearts_9595life2Objects3[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() >= 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life3"), gdjs.level_322Code.GDhearts_9595life3Objects3);
{for(var i = 0, len = gdjs.level_322Code.GDhearts_9595life3Objects3.length ;i < len;++i) {
    gdjs.level_322Code.GDhearts_9595life3Objects3[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() < 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life"), gdjs.level_322Code.GDhearts_9595lifeObjects3);
{for(var i = 0, len = gdjs.level_322Code.GDhearts_9595lifeObjects3.length ;i < len;++i) {
    gdjs.level_322Code.GDhearts_9595lifeObjects3[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() < 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life2"), gdjs.level_322Code.GDhearts_9595life2Objects3);
{for(var i = 0, len = gdjs.level_322Code.GDhearts_9595life2Objects3.length ;i < len;++i) {
    gdjs.level_322Code.GDhearts_9595life2Objects3[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() < 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life3"), gdjs.level_322Code.GDhearts_9595life3Objects3);
{for(var i = 0, len = gdjs.level_322Code.GDhearts_9595life3Objects3.length ;i < len;++i) {
    gdjs.level_322Code.GDhearts_9595life3Objects3[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() == 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "game over", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.level_322Code.GDball_9595guyObjects2);
gdjs.copyArray(runtimeScene.getObjects("hearts_life"), gdjs.level_322Code.GDhearts_9595lifeObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects2Objects, gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDhearts_95959595lifeObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level_322Code.GDhearts_9595lifeObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(4).add(1);
}
{for(var i = 0, len = gdjs.level_322Code.GDhearts_9595lifeObjects2.length ;i < len;++i) {
    gdjs.level_322Code.GDhearts_9595lifeObjects2[i].deleteFromScene(runtimeScene);
}
}
}

}


};gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects2Objects = Hashtable.newFrom({"ball_guy": gdjs.level_322Code.GDball_9595guyObjects2});
gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDdoorObjects2Objects = Hashtable.newFrom({"door": gdjs.level_322Code.GDdoorObjects2});
gdjs.level_322Code.eventsList2 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.level_322Code.GDball_9595guyObjects2);
gdjs.copyArray(runtimeScene.getObjects("deathblock"), gdjs.level_322Code.GDdeathblockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects2Objects, gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDdeathblockObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level_322Code.GDball_9595guyObjects2 */
{for(var i = 0, len = gdjs.level_322Code.GDball_9595guyObjects2.length ;i < len;++i) {
    gdjs.level_322Code.GDball_9595guyObjects2[i].getBehavior("Animation").setAnimationName("ball_guy_death");
}
}

{ //Subevents
gdjs.level_322Code.eventsList0(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.level_322Code.GDball_9595guyObjects2);
gdjs.copyArray(runtimeScene.getObjects("key2"), gdjs.level_322Code.GDkey2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects2Objects, gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDkey2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level_322Code.GDkey2Objects2 */
{for(var i = 0, len = gdjs.level_322Code.GDkey2Objects2.length ;i < len;++i) {
    gdjs.level_322Code.GDkey2Objects2[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(5).setBoolean(true);
}
{for(var i = 0, len = gdjs.level_322Code.GDkey2Objects2.length ;i < len;++i) {
    gdjs.level_322Code.GDkey2Objects2[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("scoreboard"), gdjs.level_322Code.GDscoreboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("timekeeper"), gdjs.level_322Code.GDtimekeeperObjects2);
{for(var i = 0, len = gdjs.level_322Code.GDscoreboardObjects2.length ;i < len;++i) {
    gdjs.level_322Code.GDscoreboardObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber()));
}
}
{for(var i = 0, len = gdjs.level_322Code.GDtimekeeperObjects2.length ;i < len;++i) {
    gdjs.level_322Code.GDtimekeeperObjects2[i].getBehavior("Text").setText("Time: " + gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "timelevel1"))));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("key2"), gdjs.level_322Code.GDkey2Objects2);
gdjs.copyArray(runtimeScene.getObjects("no_key"), gdjs.level_322Code.GDno_9595keyObjects2);
{for(var i = 0, len = gdjs.level_322Code.GDkey2Objects2.length ;i < len;++i) {
    gdjs.level_322Code.GDkey2Objects2[i].hide();
}
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "timelevel1");
}
{for(var i = 0, len = gdjs.level_322Code.GDno_9595keyObjects2.length ;i < len;++i) {
    gdjs.level_322Code.GDno_9595keyObjects2[i].hide();
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.level_322Code.GDball_9595guyObjects2);
gdjs.copyArray(runtimeScene.getObjects("door"), gdjs.level_322Code.GDdoorObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects2Objects, gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDdoorObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(5).getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("no_key"), gdjs.level_322Code.GDno_9595keyObjects2);
{for(var i = 0, len = gdjs.level_322Code.GDno_9595keyObjects2.length ;i < len;++i) {
    gdjs.level_322Code.GDno_9595keyObjects2[i].hide(false);
}
}
}

}


{


gdjs.level_322Code.eventsList1(runtimeScene);
}


{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.level_322Code.GDball_9595guyObjects2);
gdjs.copyArray(runtimeScene.getObjects("door"), gdjs.level_322Code.GDdoorObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects2Objects, gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDdoorObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(5).getAsBoolean();
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber() >= 9);
}
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 3", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(5).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("no_key"), gdjs.level_322Code.GDno_9595keyObjects1);
{for(var i = 0, len = gdjs.level_322Code.GDno_9595keyObjects1.length ;i < len;++i) {
    gdjs.level_322Code.GDno_9595keyObjects1[i].hide();
}
}
}

}


};gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects2Objects = Hashtable.newFrom({"ball_guy": gdjs.level_322Code.GDball_9595guyObjects2});
gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDcoinObjects2Objects = Hashtable.newFrom({"coin": gdjs.level_322Code.GDcoinObjects2});
gdjs.level_322Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.level_322Code.GDball_9595guyObjects2);
gdjs.copyArray(runtimeScene.getObjects("coin"), gdjs.level_322Code.GDcoinObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects2Objects, gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDcoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.level_322Code.GDcoinObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}
{for(var i = 0, len = gdjs.level_322Code.GDcoinObjects2.length ;i < len;++i) {
    gdjs.level_322Code.GDcoinObjects2[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "coin soud2", false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects1Objects = Hashtable.newFrom({"ball_guy": gdjs.level_322Code.GDball_9595guyObjects1});
gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDguy_95959595sprite_95959595cloneObjects1Objects = Hashtable.newFrom({"guy_sprite_clone": gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects1});
gdjs.level_322Code.asyncCallback16256972 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_322Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 2", false);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).sub(1);
}
gdjs.level_322Code.localVariables.length = 0;
}
gdjs.level_322Code.idToCallbackMap.set(16256972, gdjs.level_322Code.asyncCallback16256972);
gdjs.level_322Code.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_322Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.level_322Code.asyncCallback16256972(runtimeScene, asyncObjectsList)), 16256972, asyncObjectsList);
}
}

}


};gdjs.level_322Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.level_322Code.GDball_9595guyObjects1);
gdjs.copyArray(runtimeScene.getObjects("guy_sprite_clone"), gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects1Objects, gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDguy_95959595sprite_95959595cloneObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16256276);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_322Code.GDball_9595guyObjects1 */
{for(var i = 0, len = gdjs.level_322Code.GDball_9595guyObjects1.length ;i < len;++i) {
    gdjs.level_322Code.GDball_9595guyObjects1[i].getBehavior("Animation").setAnimationName("ball_guy_death");
}
}

{ //Subevents
gdjs.level_322Code.eventsList4(runtimeScene);} //End of subevents
}

}


};gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects1Objects = Hashtable.newFrom({"ball_guy": gdjs.level_322Code.GDball_9595guyObjects1});
gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDguy_95959595sprite_95959595cloneObjects1Objects = Hashtable.newFrom({"guy_sprite_clone": gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects1});
gdjs.level_322Code.asyncCallback16258796 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.level_322Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 2", false);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).sub(1);
}
gdjs.level_322Code.localVariables.length = 0;
}
gdjs.level_322Code.idToCallbackMap.set(16258796, gdjs.level_322Code.asyncCallback16258796);
gdjs.level_322Code.eventsList6 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.level_322Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.level_322Code.asyncCallback16258796(runtimeScene, asyncObjectsList)), 16258796, asyncObjectsList);
}
}

}


};gdjs.level_322Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.level_322Code.GDball_9595guyObjects1);
gdjs.copyArray(runtimeScene.getObjects("guy_sprite_clone"), gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDball_95959595guyObjects1Objects, gdjs.level_322Code.mapOfGDgdjs_9546level_9595322Code_9546GDguy_95959595sprite_95959595cloneObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16258220);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.level_322Code.GDball_9595guyObjects1 */
{for(var i = 0, len = gdjs.level_322Code.GDball_9595guyObjects1.length ;i < len;++i) {
    gdjs.level_322Code.GDball_9595guyObjects1[i].getBehavior("Animation").setAnimationName("death");
}
}

{ //Subevents
gdjs.level_322Code.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.level_322Code.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("background_tutorial"), gdjs.level_322Code.GDbackground_9595tutorialObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.level_322Code.GDbackground_9595tutorialObjects1.length;i<l;++i) {
    if ( gdjs.level_322Code.GDbackground_9595tutorialObjects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.level_322Code.GDbackground_9595tutorialObjects1[k] = gdjs.level_322Code.GDbackground_9595tutorialObjects1[i];
        ++k;
    }
}
gdjs.level_322Code.GDbackground_9595tutorialObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "tutorial/background", false);
}
}

}


};gdjs.level_322Code.eventsList9 = function(runtimeScene) {

{


gdjs.level_322Code.eventsList2(runtimeScene);
}


{


gdjs.level_322Code.eventsList3(runtimeScene);
}


{


gdjs.level_322Code.eventsList5(runtimeScene);
}


{


gdjs.level_322Code.eventsList7(runtimeScene);
}


{


gdjs.level_322Code.eventsList8(runtimeScene);
}


};

gdjs.level_322Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.level_322Code.GDblockObjects1.length = 0;
gdjs.level_322Code.GDblockObjects2.length = 0;
gdjs.level_322Code.GDblockObjects3.length = 0;
gdjs.level_322Code.GDblockObjects4.length = 0;
gdjs.level_322Code.GDgroundObjects1.length = 0;
gdjs.level_322Code.GDgroundObjects2.length = 0;
gdjs.level_322Code.GDgroundObjects3.length = 0;
gdjs.level_322Code.GDgroundObjects4.length = 0;
gdjs.level_322Code.GDgood_9595guy_9595sprite_9595textObjects1.length = 0;
gdjs.level_322Code.GDgood_9595guy_9595sprite_9595textObjects2.length = 0;
gdjs.level_322Code.GDgood_9595guy_9595sprite_9595textObjects3.length = 0;
gdjs.level_322Code.GDgood_9595guy_9595sprite_9595textObjects4.length = 0;
gdjs.level_322Code.GDbackground_9595tutorialObjects1.length = 0;
gdjs.level_322Code.GDbackground_9595tutorialObjects2.length = 0;
gdjs.level_322Code.GDbackground_9595tutorialObjects3.length = 0;
gdjs.level_322Code.GDbackground_9595tutorialObjects4.length = 0;
gdjs.level_322Code.GDghost_9595blockObjects1.length = 0;
gdjs.level_322Code.GDghost_9595blockObjects2.length = 0;
gdjs.level_322Code.GDghost_9595blockObjects3.length = 0;
gdjs.level_322Code.GDghost_9595blockObjects4.length = 0;
gdjs.level_322Code.GDbottomObjects1.length = 0;
gdjs.level_322Code.GDbottomObjects2.length = 0;
gdjs.level_322Code.GDbottomObjects3.length = 0;
gdjs.level_322Code.GDbottomObjects4.length = 0;
gdjs.level_322Code.GDhearts_9595lifeObjects1.length = 0;
gdjs.level_322Code.GDhearts_9595lifeObjects2.length = 0;
gdjs.level_322Code.GDhearts_9595lifeObjects3.length = 0;
gdjs.level_322Code.GDhearts_9595lifeObjects4.length = 0;
gdjs.level_322Code.GDhearts_9595life2Objects1.length = 0;
gdjs.level_322Code.GDhearts_9595life2Objects2.length = 0;
gdjs.level_322Code.GDhearts_9595life2Objects3.length = 0;
gdjs.level_322Code.GDhearts_9595life2Objects4.length = 0;
gdjs.level_322Code.GDhearts_9595life3Objects1.length = 0;
gdjs.level_322Code.GDhearts_9595life3Objects2.length = 0;
gdjs.level_322Code.GDhearts_9595life3Objects3.length = 0;
gdjs.level_322Code.GDhearts_9595life3Objects4.length = 0;
gdjs.level_322Code.GDball_9595guyObjects1.length = 0;
gdjs.level_322Code.GDball_9595guyObjects2.length = 0;
gdjs.level_322Code.GDball_9595guyObjects3.length = 0;
gdjs.level_322Code.GDball_9595guyObjects4.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects3.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects4.length = 0;
gdjs.level_322Code.GDguy_9595spriteObjects1.length = 0;
gdjs.level_322Code.GDguy_9595spriteObjects2.length = 0;
gdjs.level_322Code.GDguy_9595spriteObjects3.length = 0;
gdjs.level_322Code.GDguy_9595spriteObjects4.length = 0;
gdjs.level_322Code.GDtimekeeperObjects1.length = 0;
gdjs.level_322Code.GDtimekeeperObjects2.length = 0;
gdjs.level_322Code.GDtimekeeperObjects3.length = 0;
gdjs.level_322Code.GDtimekeeperObjects4.length = 0;
gdjs.level_322Code.GDdeathblockObjects1.length = 0;
gdjs.level_322Code.GDdeathblockObjects2.length = 0;
gdjs.level_322Code.GDdeathblockObjects3.length = 0;
gdjs.level_322Code.GDdeathblockObjects4.length = 0;
gdjs.level_322Code.GDkey2Objects1.length = 0;
gdjs.level_322Code.GDkey2Objects2.length = 0;
gdjs.level_322Code.GDkey2Objects3.length = 0;
gdjs.level_322Code.GDkey2Objects4.length = 0;
gdjs.level_322Code.GDscoreboardObjects1.length = 0;
gdjs.level_322Code.GDscoreboardObjects2.length = 0;
gdjs.level_322Code.GDscoreboardObjects3.length = 0;
gdjs.level_322Code.GDscoreboardObjects4.length = 0;
gdjs.level_322Code.GDdoorObjects1.length = 0;
gdjs.level_322Code.GDdoorObjects2.length = 0;
gdjs.level_322Code.GDdoorObjects3.length = 0;
gdjs.level_322Code.GDdoorObjects4.length = 0;
gdjs.level_322Code.GDno_9595keyObjects1.length = 0;
gdjs.level_322Code.GDno_9595keyObjects2.length = 0;
gdjs.level_322Code.GDno_9595keyObjects3.length = 0;
gdjs.level_322Code.GDno_9595keyObjects4.length = 0;
gdjs.level_322Code.GDcoinObjects1.length = 0;
gdjs.level_322Code.GDcoinObjects2.length = 0;
gdjs.level_322Code.GDcoinObjects3.length = 0;
gdjs.level_322Code.GDcoinObjects4.length = 0;
gdjs.level_322Code.GDplatform_9595viruseObjects1.length = 0;
gdjs.level_322Code.GDplatform_9595viruseObjects2.length = 0;
gdjs.level_322Code.GDplatform_9595viruseObjects3.length = 0;
gdjs.level_322Code.GDplatform_9595viruseObjects4.length = 0;
gdjs.level_322Code.GDboss_9595heartObjects1.length = 0;
gdjs.level_322Code.GDboss_9595heartObjects2.length = 0;
gdjs.level_322Code.GDboss_9595heartObjects3.length = 0;
gdjs.level_322Code.GDboss_9595heartObjects4.length = 0;
gdjs.level_322Code.GDboss_9595heart2Objects1.length = 0;
gdjs.level_322Code.GDboss_9595heart2Objects2.length = 0;
gdjs.level_322Code.GDboss_9595heart2Objects3.length = 0;
gdjs.level_322Code.GDboss_9595heart2Objects4.length = 0;
gdjs.level_322Code.GDboss_9595heart3Objects1.length = 0;
gdjs.level_322Code.GDboss_9595heart3Objects2.length = 0;
gdjs.level_322Code.GDboss_9595heart3Objects3.length = 0;
gdjs.level_322Code.GDboss_9595heart3Objects4.length = 0;
gdjs.level_322Code.GDevile_9595guyObjects1.length = 0;
gdjs.level_322Code.GDevile_9595guyObjects2.length = 0;
gdjs.level_322Code.GDevile_9595guyObjects3.length = 0;
gdjs.level_322Code.GDevile_9595guyObjects4.length = 0;
gdjs.level_322Code.GDguy_9595sprite2Objects1.length = 0;
gdjs.level_322Code.GDguy_9595sprite2Objects2.length = 0;
gdjs.level_322Code.GDguy_9595sprite2Objects3.length = 0;
gdjs.level_322Code.GDguy_9595sprite2Objects4.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595clone2Objects2.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595clone2Objects3.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595clone2Objects4.length = 0;

gdjs.level_322Code.eventsList9(runtimeScene);
gdjs.level_322Code.GDblockObjects1.length = 0;
gdjs.level_322Code.GDblockObjects2.length = 0;
gdjs.level_322Code.GDblockObjects3.length = 0;
gdjs.level_322Code.GDblockObjects4.length = 0;
gdjs.level_322Code.GDgroundObjects1.length = 0;
gdjs.level_322Code.GDgroundObjects2.length = 0;
gdjs.level_322Code.GDgroundObjects3.length = 0;
gdjs.level_322Code.GDgroundObjects4.length = 0;
gdjs.level_322Code.GDgood_9595guy_9595sprite_9595textObjects1.length = 0;
gdjs.level_322Code.GDgood_9595guy_9595sprite_9595textObjects2.length = 0;
gdjs.level_322Code.GDgood_9595guy_9595sprite_9595textObjects3.length = 0;
gdjs.level_322Code.GDgood_9595guy_9595sprite_9595textObjects4.length = 0;
gdjs.level_322Code.GDbackground_9595tutorialObjects1.length = 0;
gdjs.level_322Code.GDbackground_9595tutorialObjects2.length = 0;
gdjs.level_322Code.GDbackground_9595tutorialObjects3.length = 0;
gdjs.level_322Code.GDbackground_9595tutorialObjects4.length = 0;
gdjs.level_322Code.GDghost_9595blockObjects1.length = 0;
gdjs.level_322Code.GDghost_9595blockObjects2.length = 0;
gdjs.level_322Code.GDghost_9595blockObjects3.length = 0;
gdjs.level_322Code.GDghost_9595blockObjects4.length = 0;
gdjs.level_322Code.GDbottomObjects1.length = 0;
gdjs.level_322Code.GDbottomObjects2.length = 0;
gdjs.level_322Code.GDbottomObjects3.length = 0;
gdjs.level_322Code.GDbottomObjects4.length = 0;
gdjs.level_322Code.GDhearts_9595lifeObjects1.length = 0;
gdjs.level_322Code.GDhearts_9595lifeObjects2.length = 0;
gdjs.level_322Code.GDhearts_9595lifeObjects3.length = 0;
gdjs.level_322Code.GDhearts_9595lifeObjects4.length = 0;
gdjs.level_322Code.GDhearts_9595life2Objects1.length = 0;
gdjs.level_322Code.GDhearts_9595life2Objects2.length = 0;
gdjs.level_322Code.GDhearts_9595life2Objects3.length = 0;
gdjs.level_322Code.GDhearts_9595life2Objects4.length = 0;
gdjs.level_322Code.GDhearts_9595life3Objects1.length = 0;
gdjs.level_322Code.GDhearts_9595life3Objects2.length = 0;
gdjs.level_322Code.GDhearts_9595life3Objects3.length = 0;
gdjs.level_322Code.GDhearts_9595life3Objects4.length = 0;
gdjs.level_322Code.GDball_9595guyObjects1.length = 0;
gdjs.level_322Code.GDball_9595guyObjects2.length = 0;
gdjs.level_322Code.GDball_9595guyObjects3.length = 0;
gdjs.level_322Code.GDball_9595guyObjects4.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects3.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595cloneObjects4.length = 0;
gdjs.level_322Code.GDguy_9595spriteObjects1.length = 0;
gdjs.level_322Code.GDguy_9595spriteObjects2.length = 0;
gdjs.level_322Code.GDguy_9595spriteObjects3.length = 0;
gdjs.level_322Code.GDguy_9595spriteObjects4.length = 0;
gdjs.level_322Code.GDtimekeeperObjects1.length = 0;
gdjs.level_322Code.GDtimekeeperObjects2.length = 0;
gdjs.level_322Code.GDtimekeeperObjects3.length = 0;
gdjs.level_322Code.GDtimekeeperObjects4.length = 0;
gdjs.level_322Code.GDdeathblockObjects1.length = 0;
gdjs.level_322Code.GDdeathblockObjects2.length = 0;
gdjs.level_322Code.GDdeathblockObjects3.length = 0;
gdjs.level_322Code.GDdeathblockObjects4.length = 0;
gdjs.level_322Code.GDkey2Objects1.length = 0;
gdjs.level_322Code.GDkey2Objects2.length = 0;
gdjs.level_322Code.GDkey2Objects3.length = 0;
gdjs.level_322Code.GDkey2Objects4.length = 0;
gdjs.level_322Code.GDscoreboardObjects1.length = 0;
gdjs.level_322Code.GDscoreboardObjects2.length = 0;
gdjs.level_322Code.GDscoreboardObjects3.length = 0;
gdjs.level_322Code.GDscoreboardObjects4.length = 0;
gdjs.level_322Code.GDdoorObjects1.length = 0;
gdjs.level_322Code.GDdoorObjects2.length = 0;
gdjs.level_322Code.GDdoorObjects3.length = 0;
gdjs.level_322Code.GDdoorObjects4.length = 0;
gdjs.level_322Code.GDno_9595keyObjects1.length = 0;
gdjs.level_322Code.GDno_9595keyObjects2.length = 0;
gdjs.level_322Code.GDno_9595keyObjects3.length = 0;
gdjs.level_322Code.GDno_9595keyObjects4.length = 0;
gdjs.level_322Code.GDcoinObjects1.length = 0;
gdjs.level_322Code.GDcoinObjects2.length = 0;
gdjs.level_322Code.GDcoinObjects3.length = 0;
gdjs.level_322Code.GDcoinObjects4.length = 0;
gdjs.level_322Code.GDplatform_9595viruseObjects1.length = 0;
gdjs.level_322Code.GDplatform_9595viruseObjects2.length = 0;
gdjs.level_322Code.GDplatform_9595viruseObjects3.length = 0;
gdjs.level_322Code.GDplatform_9595viruseObjects4.length = 0;
gdjs.level_322Code.GDboss_9595heartObjects1.length = 0;
gdjs.level_322Code.GDboss_9595heartObjects2.length = 0;
gdjs.level_322Code.GDboss_9595heartObjects3.length = 0;
gdjs.level_322Code.GDboss_9595heartObjects4.length = 0;
gdjs.level_322Code.GDboss_9595heart2Objects1.length = 0;
gdjs.level_322Code.GDboss_9595heart2Objects2.length = 0;
gdjs.level_322Code.GDboss_9595heart2Objects3.length = 0;
gdjs.level_322Code.GDboss_9595heart2Objects4.length = 0;
gdjs.level_322Code.GDboss_9595heart3Objects1.length = 0;
gdjs.level_322Code.GDboss_9595heart3Objects2.length = 0;
gdjs.level_322Code.GDboss_9595heart3Objects3.length = 0;
gdjs.level_322Code.GDboss_9595heart3Objects4.length = 0;
gdjs.level_322Code.GDevile_9595guyObjects1.length = 0;
gdjs.level_322Code.GDevile_9595guyObjects2.length = 0;
gdjs.level_322Code.GDevile_9595guyObjects3.length = 0;
gdjs.level_322Code.GDevile_9595guyObjects4.length = 0;
gdjs.level_322Code.GDguy_9595sprite2Objects1.length = 0;
gdjs.level_322Code.GDguy_9595sprite2Objects2.length = 0;
gdjs.level_322Code.GDguy_9595sprite2Objects3.length = 0;
gdjs.level_322Code.GDguy_9595sprite2Objects4.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595clone2Objects2.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595clone2Objects3.length = 0;
gdjs.level_322Code.GDguy_9595sprite_9595clone2Objects4.length = 0;


return;

}

gdjs['level_322Code'] = gdjs.level_322Code;
