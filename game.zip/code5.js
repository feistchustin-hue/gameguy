gdjs.game_32overCode = {};
gdjs.game_32overCode.localVariables = [];
gdjs.game_32overCode.idToCallbackMap = new Map();
gdjs.game_32overCode.GDGAME_9595OVER_9595TEXTObjects1= [];
gdjs.game_32overCode.GDGAME_9595OVER_9595TEXTObjects2= [];
gdjs.game_32overCode.GDlevel_95951Objects1= [];
gdjs.game_32overCode.GDlevel_95951Objects2= [];
gdjs.game_32overCode.GDhearts_9595lifeObjects1= [];
gdjs.game_32overCode.GDhearts_9595lifeObjects2= [];
gdjs.game_32overCode.GDhearts_9595life2Objects1= [];
gdjs.game_32overCode.GDhearts_9595life2Objects2= [];
gdjs.game_32overCode.GDhearts_9595life3Objects1= [];
gdjs.game_32overCode.GDhearts_9595life3Objects2= [];
gdjs.game_32overCode.GDball_9595guyObjects1= [];
gdjs.game_32overCode.GDball_9595guyObjects2= [];
gdjs.game_32overCode.GDguy_9595sprite_9595cloneObjects1= [];
gdjs.game_32overCode.GDguy_9595sprite_9595cloneObjects2= [];
gdjs.game_32overCode.GDguy_9595spriteObjects1= [];
gdjs.game_32overCode.GDguy_9595spriteObjects2= [];
gdjs.game_32overCode.GDtimekeeperObjects1= [];
gdjs.game_32overCode.GDtimekeeperObjects2= [];
gdjs.game_32overCode.GDdeathblockObjects1= [];
gdjs.game_32overCode.GDdeathblockObjects2= [];
gdjs.game_32overCode.GDkey2Objects1= [];
gdjs.game_32overCode.GDkey2Objects2= [];
gdjs.game_32overCode.GDscoreboardObjects1= [];
gdjs.game_32overCode.GDscoreboardObjects2= [];
gdjs.game_32overCode.GDdoorObjects1= [];
gdjs.game_32overCode.GDdoorObjects2= [];
gdjs.game_32overCode.GDno_9595keyObjects1= [];
gdjs.game_32overCode.GDno_9595keyObjects2= [];
gdjs.game_32overCode.GDcoinObjects1= [];
gdjs.game_32overCode.GDcoinObjects2= [];
gdjs.game_32overCode.GDplatform_9595viruseObjects1= [];
gdjs.game_32overCode.GDplatform_9595viruseObjects2= [];
gdjs.game_32overCode.GDboss_9595heartObjects1= [];
gdjs.game_32overCode.GDboss_9595heartObjects2= [];
gdjs.game_32overCode.GDboss_9595heart2Objects1= [];
gdjs.game_32overCode.GDboss_9595heart2Objects2= [];
gdjs.game_32overCode.GDboss_9595heart3Objects1= [];
gdjs.game_32overCode.GDboss_9595heart3Objects2= [];
gdjs.game_32overCode.GDevile_9595guyObjects1= [];
gdjs.game_32overCode.GDevile_9595guyObjects2= [];
gdjs.game_32overCode.GDguy_9595sprite2Objects1= [];
gdjs.game_32overCode.GDguy_9595sprite2Objects2= [];
gdjs.game_32overCode.GDguy_9595sprite_9595clone2Objects1= [];
gdjs.game_32overCode.GDguy_9595sprite_9595clone2Objects2= [];


gdjs.game_32overCode.eventsList0 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("level_1"), gdjs.game_32overCode.GDlevel_95951Objects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.game_32overCode.GDlevel_95951Objects1.length;i<l;++i) {
    if ( gdjs.game_32overCode.GDlevel_95951Objects1[i].IsClicked(null) ) {
        isConditionTrue_0 = true;
        gdjs.game_32overCode.GDlevel_95951Objects1[k] = gdjs.game_32overCode.GDlevel_95951Objects1[i];
        ++k;
    }
}
gdjs.game_32overCode.GDlevel_95951Objects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 1", false);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).setNumber(2);
}
}

}


};

gdjs.game_32overCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.game_32overCode.GDGAME_9595OVER_9595TEXTObjects1.length = 0;
gdjs.game_32overCode.GDGAME_9595OVER_9595TEXTObjects2.length = 0;
gdjs.game_32overCode.GDlevel_95951Objects1.length = 0;
gdjs.game_32overCode.GDlevel_95951Objects2.length = 0;
gdjs.game_32overCode.GDhearts_9595lifeObjects1.length = 0;
gdjs.game_32overCode.GDhearts_9595lifeObjects2.length = 0;
gdjs.game_32overCode.GDhearts_9595life2Objects1.length = 0;
gdjs.game_32overCode.GDhearts_9595life2Objects2.length = 0;
gdjs.game_32overCode.GDhearts_9595life3Objects1.length = 0;
gdjs.game_32overCode.GDhearts_9595life3Objects2.length = 0;
gdjs.game_32overCode.GDball_9595guyObjects1.length = 0;
gdjs.game_32overCode.GDball_9595guyObjects2.length = 0;
gdjs.game_32overCode.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.game_32overCode.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.game_32overCode.GDguy_9595spriteObjects1.length = 0;
gdjs.game_32overCode.GDguy_9595spriteObjects2.length = 0;
gdjs.game_32overCode.GDtimekeeperObjects1.length = 0;
gdjs.game_32overCode.GDtimekeeperObjects2.length = 0;
gdjs.game_32overCode.GDdeathblockObjects1.length = 0;
gdjs.game_32overCode.GDdeathblockObjects2.length = 0;
gdjs.game_32overCode.GDkey2Objects1.length = 0;
gdjs.game_32overCode.GDkey2Objects2.length = 0;
gdjs.game_32overCode.GDscoreboardObjects1.length = 0;
gdjs.game_32overCode.GDscoreboardObjects2.length = 0;
gdjs.game_32overCode.GDdoorObjects1.length = 0;
gdjs.game_32overCode.GDdoorObjects2.length = 0;
gdjs.game_32overCode.GDno_9595keyObjects1.length = 0;
gdjs.game_32overCode.GDno_9595keyObjects2.length = 0;
gdjs.game_32overCode.GDcoinObjects1.length = 0;
gdjs.game_32overCode.GDcoinObjects2.length = 0;
gdjs.game_32overCode.GDplatform_9595viruseObjects1.length = 0;
gdjs.game_32overCode.GDplatform_9595viruseObjects2.length = 0;
gdjs.game_32overCode.GDboss_9595heartObjects1.length = 0;
gdjs.game_32overCode.GDboss_9595heartObjects2.length = 0;
gdjs.game_32overCode.GDboss_9595heart2Objects1.length = 0;
gdjs.game_32overCode.GDboss_9595heart2Objects2.length = 0;
gdjs.game_32overCode.GDboss_9595heart3Objects1.length = 0;
gdjs.game_32overCode.GDboss_9595heart3Objects2.length = 0;
gdjs.game_32overCode.GDevile_9595guyObjects1.length = 0;
gdjs.game_32overCode.GDevile_9595guyObjects2.length = 0;
gdjs.game_32overCode.GDguy_9595sprite2Objects1.length = 0;
gdjs.game_32overCode.GDguy_9595sprite2Objects2.length = 0;
gdjs.game_32overCode.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.game_32overCode.GDguy_9595sprite_9595clone2Objects2.length = 0;

gdjs.game_32overCode.eventsList0(runtimeScene);
gdjs.game_32overCode.GDGAME_9595OVER_9595TEXTObjects1.length = 0;
gdjs.game_32overCode.GDGAME_9595OVER_9595TEXTObjects2.length = 0;
gdjs.game_32overCode.GDlevel_95951Objects1.length = 0;
gdjs.game_32overCode.GDlevel_95951Objects2.length = 0;
gdjs.game_32overCode.GDhearts_9595lifeObjects1.length = 0;
gdjs.game_32overCode.GDhearts_9595lifeObjects2.length = 0;
gdjs.game_32overCode.GDhearts_9595life2Objects1.length = 0;
gdjs.game_32overCode.GDhearts_9595life2Objects2.length = 0;
gdjs.game_32overCode.GDhearts_9595life3Objects1.length = 0;
gdjs.game_32overCode.GDhearts_9595life3Objects2.length = 0;
gdjs.game_32overCode.GDball_9595guyObjects1.length = 0;
gdjs.game_32overCode.GDball_9595guyObjects2.length = 0;
gdjs.game_32overCode.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.game_32overCode.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.game_32overCode.GDguy_9595spriteObjects1.length = 0;
gdjs.game_32overCode.GDguy_9595spriteObjects2.length = 0;
gdjs.game_32overCode.GDtimekeeperObjects1.length = 0;
gdjs.game_32overCode.GDtimekeeperObjects2.length = 0;
gdjs.game_32overCode.GDdeathblockObjects1.length = 0;
gdjs.game_32overCode.GDdeathblockObjects2.length = 0;
gdjs.game_32overCode.GDkey2Objects1.length = 0;
gdjs.game_32overCode.GDkey2Objects2.length = 0;
gdjs.game_32overCode.GDscoreboardObjects1.length = 0;
gdjs.game_32overCode.GDscoreboardObjects2.length = 0;
gdjs.game_32overCode.GDdoorObjects1.length = 0;
gdjs.game_32overCode.GDdoorObjects2.length = 0;
gdjs.game_32overCode.GDno_9595keyObjects1.length = 0;
gdjs.game_32overCode.GDno_9595keyObjects2.length = 0;
gdjs.game_32overCode.GDcoinObjects1.length = 0;
gdjs.game_32overCode.GDcoinObjects2.length = 0;
gdjs.game_32overCode.GDplatform_9595viruseObjects1.length = 0;
gdjs.game_32overCode.GDplatform_9595viruseObjects2.length = 0;
gdjs.game_32overCode.GDboss_9595heartObjects1.length = 0;
gdjs.game_32overCode.GDboss_9595heartObjects2.length = 0;
gdjs.game_32overCode.GDboss_9595heart2Objects1.length = 0;
gdjs.game_32overCode.GDboss_9595heart2Objects2.length = 0;
gdjs.game_32overCode.GDboss_9595heart3Objects1.length = 0;
gdjs.game_32overCode.GDboss_9595heart3Objects2.length = 0;
gdjs.game_32overCode.GDevile_9595guyObjects1.length = 0;
gdjs.game_32overCode.GDevile_9595guyObjects2.length = 0;
gdjs.game_32overCode.GDguy_9595sprite2Objects1.length = 0;
gdjs.game_32overCode.GDguy_9595sprite2Objects2.length = 0;
gdjs.game_32overCode.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.game_32overCode.GDguy_9595sprite_9595clone2Objects2.length = 0;


return;

}

gdjs['game_32overCode'] = gdjs.game_32overCode;
