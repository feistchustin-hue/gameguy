gdjs.the_32endCode = {};
gdjs.the_32endCode.localVariables = [];
gdjs.the_32endCode.idToCallbackMap = new Map();


gdjs.the_32endCode.eventsList0 = function(runtimeScene) {

};

gdjs.the_32endCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();


gdjs.the_32endCode.eventsList0(runtimeScene);


return;

}

gdjs['the_32endCode'] = gdjs.the_32endCode;
