gdjs.final_32level_324Code = {};
gdjs.final_32level_324Code.localVariables = [];
gdjs.final_32level_324Code.idToCallbackMap = new Map();
gdjs.final_32level_324Code.GDNewTiledSpriteObjects1= [];
gdjs.final_32level_324Code.GDNewTiledSpriteObjects2= [];
gdjs.final_32level_324Code.GDNewTiledSpriteObjects3= [];
gdjs.final_32level_324Code.GDlaserObjects1= [];
gdjs.final_32level_324Code.GDlaserObjects2= [];
gdjs.final_32level_324Code.GDlaserObjects3= [];
gdjs.final_32level_324Code.GDNewTextObjects1= [];
gdjs.final_32level_324Code.GDNewTextObjects2= [];
gdjs.final_32level_324Code.GDNewTextObjects3= [];
gdjs.final_32level_324Code.GDhearts_9595lifeObjects1= [];
gdjs.final_32level_324Code.GDhearts_9595lifeObjects2= [];
gdjs.final_32level_324Code.GDhearts_9595lifeObjects3= [];
gdjs.final_32level_324Code.GDhearts_9595life2Objects1= [];
gdjs.final_32level_324Code.GDhearts_9595life2Objects2= [];
gdjs.final_32level_324Code.GDhearts_9595life2Objects3= [];
gdjs.final_32level_324Code.GDhearts_9595life3Objects1= [];
gdjs.final_32level_324Code.GDhearts_9595life3Objects2= [];
gdjs.final_32level_324Code.GDhearts_9595life3Objects3= [];
gdjs.final_32level_324Code.GDball_9595guyObjects1= [];
gdjs.final_32level_324Code.GDball_9595guyObjects2= [];
gdjs.final_32level_324Code.GDball_9595guyObjects3= [];
gdjs.final_32level_324Code.GDguy_9595sprite_9595cloneObjects1= [];
gdjs.final_32level_324Code.GDguy_9595sprite_9595cloneObjects2= [];
gdjs.final_32level_324Code.GDguy_9595sprite_9595cloneObjects3= [];
gdjs.final_32level_324Code.GDguy_9595spriteObjects1= [];
gdjs.final_32level_324Code.GDguy_9595spriteObjects2= [];
gdjs.final_32level_324Code.GDguy_9595spriteObjects3= [];
gdjs.final_32level_324Code.GDtimekeeperObjects1= [];
gdjs.final_32level_324Code.GDtimekeeperObjects2= [];
gdjs.final_32level_324Code.GDtimekeeperObjects3= [];
gdjs.final_32level_324Code.GDdeathblockObjects1= [];
gdjs.final_32level_324Code.GDdeathblockObjects2= [];
gdjs.final_32level_324Code.GDdeathblockObjects3= [];
gdjs.final_32level_324Code.GDkey2Objects1= [];
gdjs.final_32level_324Code.GDkey2Objects2= [];
gdjs.final_32level_324Code.GDkey2Objects3= [];
gdjs.final_32level_324Code.GDscoreboardObjects1= [];
gdjs.final_32level_324Code.GDscoreboardObjects2= [];
gdjs.final_32level_324Code.GDscoreboardObjects3= [];
gdjs.final_32level_324Code.GDdoorObjects1= [];
gdjs.final_32level_324Code.GDdoorObjects2= [];
gdjs.final_32level_324Code.GDdoorObjects3= [];
gdjs.final_32level_324Code.GDno_9595keyObjects1= [];
gdjs.final_32level_324Code.GDno_9595keyObjects2= [];
gdjs.final_32level_324Code.GDno_9595keyObjects3= [];
gdjs.final_32level_324Code.GDcoinObjects1= [];
gdjs.final_32level_324Code.GDcoinObjects2= [];
gdjs.final_32level_324Code.GDcoinObjects3= [];
gdjs.final_32level_324Code.GDplatform_9595viruseObjects1= [];
gdjs.final_32level_324Code.GDplatform_9595viruseObjects2= [];
gdjs.final_32level_324Code.GDplatform_9595viruseObjects3= [];
gdjs.final_32level_324Code.GDboss_9595heartObjects1= [];
gdjs.final_32level_324Code.GDboss_9595heartObjects2= [];
gdjs.final_32level_324Code.GDboss_9595heartObjects3= [];
gdjs.final_32level_324Code.GDboss_9595heart2Objects1= [];
gdjs.final_32level_324Code.GDboss_9595heart2Objects2= [];
gdjs.final_32level_324Code.GDboss_9595heart2Objects3= [];
gdjs.final_32level_324Code.GDboss_9595heart3Objects1= [];
gdjs.final_32level_324Code.GDboss_9595heart3Objects2= [];
gdjs.final_32level_324Code.GDboss_9595heart3Objects3= [];
gdjs.final_32level_324Code.GDevile_9595guyObjects1= [];
gdjs.final_32level_324Code.GDevile_9595guyObjects2= [];
gdjs.final_32level_324Code.GDevile_9595guyObjects3= [];
gdjs.final_32level_324Code.GDguy_9595sprite2Objects1= [];
gdjs.final_32level_324Code.GDguy_9595sprite2Objects2= [];
gdjs.final_32level_324Code.GDguy_9595sprite2Objects3= [];
gdjs.final_32level_324Code.GDguy_9595sprite_9595clone2Objects1= [];
gdjs.final_32level_324Code.GDguy_9595sprite_9595clone2Objects2= [];
gdjs.final_32level_324Code.GDguy_9595sprite_9595clone2Objects3= [];


gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects1Objects = Hashtable.newFrom({"ball_guy": gdjs.final_32level_324Code.GDball_9595guyObjects1});
gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDguy_95959595sprite_95959595cloneObjects1Objects = Hashtable.newFrom({"guy_sprite_clone": gdjs.final_32level_324Code.GDguy_9595sprite_9595cloneObjects1});
gdjs.final_32level_324Code.asyncCallback16464732 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.final_32level_324Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 3", false);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).sub(1);
}
gdjs.final_32level_324Code.localVariables.length = 0;
}
gdjs.final_32level_324Code.idToCallbackMap.set(16464732, gdjs.final_32level_324Code.asyncCallback16464732);
gdjs.final_32level_324Code.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.final_32level_324Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.final_32level_324Code.asyncCallback16464732(runtimeScene, asyncObjectsList)), 16464732, asyncObjectsList);
}
}

}


};gdjs.final_32level_324Code.eventsList1 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.final_32level_324Code.GDball_9595guyObjects1);
gdjs.copyArray(runtimeScene.getObjects("guy_sprite_clone"), gdjs.final_32level_324Code.GDguy_9595sprite_9595cloneObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects1Objects, gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDguy_95959595sprite_95959595cloneObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16464516);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.final_32level_324Code.GDball_9595guyObjects1 */
{for(var i = 0, len = gdjs.final_32level_324Code.GDball_9595guyObjects1.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDball_9595guyObjects1[i].getBehavior("Animation").setAnimationName("ball_guy_death");
}
}

{ //Subevents
gdjs.final_32level_324Code.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects1Objects = Hashtable.newFrom({"ball_guy": gdjs.final_32level_324Code.GDball_9595guyObjects1});
gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDguy_95959595sprite_95959595cloneObjects1Objects = Hashtable.newFrom({"guy_sprite_clone": gdjs.final_32level_324Code.GDguy_9595sprite_9595cloneObjects1});
gdjs.final_32level_324Code.asyncCallback16466892 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.final_32level_324Code.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 3", false);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).sub(1);
}
gdjs.final_32level_324Code.localVariables.length = 0;
}
gdjs.final_32level_324Code.idToCallbackMap.set(16466892, gdjs.final_32level_324Code.asyncCallback16466892);
gdjs.final_32level_324Code.eventsList2 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.final_32level_324Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(4), (runtimeScene) => (gdjs.final_32level_324Code.asyncCallback16466892(runtimeScene, asyncObjectsList)), 16466892, asyncObjectsList);
}
}

}


};gdjs.final_32level_324Code.eventsList3 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.final_32level_324Code.GDball_9595guyObjects1);
gdjs.copyArray(runtimeScene.getObjects("guy_sprite_clone"), gdjs.final_32level_324Code.GDguy_9595sprite_9595cloneObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects1Objects, gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDguy_95959595sprite_95959595cloneObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16463564);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.final_32level_324Code.GDball_9595guyObjects1 */
{for(var i = 0, len = gdjs.final_32level_324Code.GDball_9595guyObjects1.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDball_9595guyObjects1[i].getBehavior("Animation").setAnimationName("death");
}
}

{ //Subevents
gdjs.final_32level_324Code.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects2Objects = Hashtable.newFrom({"ball_guy": gdjs.final_32level_324Code.GDball_9595guyObjects2});
gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDdeathblockObjects2Objects = Hashtable.newFrom({"deathblock": gdjs.final_32level_324Code.GDdeathblockObjects2});
gdjs.final_32level_324Code.asyncCallback16469436 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.final_32level_324Code.localVariables);
gdjs.copyArray(asyncObjectsList.getObjects("ball_guy"), gdjs.final_32level_324Code.GDball_9595guyObjects3);

gdjs.copyArray(runtimeScene.getObjects("laser"), gdjs.final_32level_324Code.GDlaserObjects3);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "level 3", false);
}
{runtimeScene.getGame().getVariables().getFromIndex(4).sub(1);
}
{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.final_32level_324Code.GDlaserObjects3.length !== 0 ? gdjs.final_32level_324Code.GDlaserObjects3[0] : null), (gdjs.final_32level_324Code.GDball_9595guyObjects3.length !== 0 ? gdjs.final_32level_324Code.GDball_9595guyObjects3[0] : null));
}
{for(var i = 0, len = gdjs.final_32level_324Code.GDlaserObjects3.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDlaserObjects3[i].hide();
}
}
gdjs.final_32level_324Code.localVariables.length = 0;
}
gdjs.final_32level_324Code.idToCallbackMap.set(16469436, gdjs.final_32level_324Code.asyncCallback16469436);
gdjs.final_32level_324Code.eventsList4 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.final_32level_324Code.localVariables);
for (const obj of gdjs.final_32level_324Code.GDball_9595guyObjects2) asyncObjectsList.addObject("ball_guy", obj);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(5), (runtimeScene) => (gdjs.final_32level_324Code.asyncCallback16469436(runtimeScene, asyncObjectsList)), 16469436, asyncObjectsList);
}
}

}


};gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects2Objects = Hashtable.newFrom({"ball_guy": gdjs.final_32level_324Code.GDball_9595guyObjects2});
gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDkey2Objects2Objects = Hashtable.newFrom({"key2": gdjs.final_32level_324Code.GDkey2Objects2});
gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects2Objects = Hashtable.newFrom({"ball_guy": gdjs.final_32level_324Code.GDball_9595guyObjects2});
gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDdoorObjects2Objects = Hashtable.newFrom({"door": gdjs.final_32level_324Code.GDdoorObjects2});
gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects2Objects = Hashtable.newFrom({"ball_guy": gdjs.final_32level_324Code.GDball_9595guyObjects2});
gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDdoorObjects2Objects = Hashtable.newFrom({"door": gdjs.final_32level_324Code.GDdoorObjects2});
gdjs.final_32level_324Code.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.final_32level_324Code.GDball_9595guyObjects2);
gdjs.copyArray(runtimeScene.getObjects("deathblock"), gdjs.final_32level_324Code.GDdeathblockObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects2Objects, gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDdeathblockObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16468796);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.final_32level_324Code.GDball_9595guyObjects2 */
{for(var i = 0, len = gdjs.final_32level_324Code.GDball_9595guyObjects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDball_9595guyObjects2[i].getBehavior("Animation").setAnimationName("ball_guy_death");
}
}

{ //Subevents
gdjs.final_32level_324Code.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.final_32level_324Code.GDball_9595guyObjects2);
gdjs.copyArray(runtimeScene.getObjects("key2"), gdjs.final_32level_324Code.GDkey2Objects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects2Objects, gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDkey2Objects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.final_32level_324Code.GDkey2Objects2 */
{for(var i = 0, len = gdjs.final_32level_324Code.GDkey2Objects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDkey2Objects2[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "New sound effect2", false, 100, 1);
}
{runtimeScene.getGame().getVariables().getFromIndex(5).setBoolean(true);
}
{for(var i = 0, len = gdjs.final_32level_324Code.GDkey2Objects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDkey2Objects2[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("scoreboard"), gdjs.final_32level_324Code.GDscoreboardObjects2);
gdjs.copyArray(runtimeScene.getObjects("timekeeper"), gdjs.final_32level_324Code.GDtimekeeperObjects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDscoreboardObjects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDscoreboardObjects2[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(runtimeScene.getGame().getVariables().getFromIndex(2).getAsNumber()));
}
}
{for(var i = 0, len = gdjs.final_32level_324Code.GDtimekeeperObjects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDtimekeeperObjects2[i].getBehavior("Text").setText("Time: " + gdjs.evtTools.common.toString(Math.floor(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "timelevel1"))));
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("key2"), gdjs.final_32level_324Code.GDkey2Objects2);
gdjs.copyArray(runtimeScene.getObjects("no_key"), gdjs.final_32level_324Code.GDno_9595keyObjects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDkey2Objects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDkey2Objects2[i].hide();
}
}
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "timelevel1");
}
{for(var i = 0, len = gdjs.final_32level_324Code.GDno_9595keyObjects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDno_9595keyObjects2[i].hide();
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).setNumber(3);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.final_32level_324Code.GDball_9595guyObjects2);
gdjs.copyArray(runtimeScene.getObjects("door"), gdjs.final_32level_324Code.GDdoorObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects2Objects, gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDdoorObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = !runtimeScene.getGame().getVariables().getFromIndex(5).getAsBoolean();
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("no_key"), gdjs.final_32level_324Code.GDno_9595keyObjects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDno_9595keyObjects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDno_9595keyObjects2[i].hide(false);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.final_32level_324Code.GDball_9595guyObjects2);
gdjs.copyArray(runtimeScene.getObjects("door"), gdjs.final_32level_324Code.GDdoorObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects2Objects, gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDdoorObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(5).getAsBoolean();
}
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "final level 4", false);
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getGame().getVariables().getFromIndex(5).getAsBoolean();
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("no_key"), gdjs.final_32level_324Code.GDno_9595keyObjects1);
{for(var i = 0, len = gdjs.final_32level_324Code.GDno_9595keyObjects1.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDno_9595keyObjects1[i].hide();
}
}
}

}


};gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects1Objects = Hashtable.newFrom({"ball_guy": gdjs.final_32level_324Code.GDball_9595guyObjects1});
gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDhearts_95959595lifeObjects1Objects = Hashtable.newFrom({"hearts_life": gdjs.final_32level_324Code.GDhearts_9595lifeObjects1});
gdjs.final_32level_324Code.eventsList6 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() >= 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life"), gdjs.final_32level_324Code.GDhearts_9595lifeObjects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDhearts_9595lifeObjects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDhearts_9595lifeObjects2[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() >= 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life2"), gdjs.final_32level_324Code.GDhearts_9595life2Objects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDhearts_9595life2Objects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDhearts_9595life2Objects2[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() >= 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life3"), gdjs.final_32level_324Code.GDhearts_9595life3Objects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDhearts_9595life3Objects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDhearts_9595life3Objects2[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() < 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life"), gdjs.final_32level_324Code.GDhearts_9595lifeObjects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDhearts_9595lifeObjects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDhearts_9595lifeObjects2[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() < 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life2"), gdjs.final_32level_324Code.GDhearts_9595life2Objects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDhearts_9595life2Objects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDhearts_9595life2Objects2[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() < 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("hearts_life3"), gdjs.final_32level_324Code.GDhearts_9595life3Objects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDhearts_9595life3Objects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDhearts_9595life3Objects2[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(4).getAsNumber() == 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "game over", false);
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.final_32level_324Code.GDball_9595guyObjects1);
gdjs.copyArray(runtimeScene.getObjects("hearts_life"), gdjs.final_32level_324Code.GDhearts_9595lifeObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects1Objects, gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDhearts_95959595lifeObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.final_32level_324Code.GDhearts_9595lifeObjects1 */
{runtimeScene.getGame().getVariables().getFromIndex(4).add(1);
}
{for(var i = 0, len = gdjs.final_32level_324Code.GDhearts_9595lifeObjects1.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDhearts_9595lifeObjects1[i].deleteFromScene(runtimeScene);
}
}
}

}


};gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects2Objects = Hashtable.newFrom({"ball_guy": gdjs.final_32level_324Code.GDball_9595guyObjects2});
gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDcoinObjects2Objects = Hashtable.newFrom({"coin": gdjs.final_32level_324Code.GDcoinObjects2});
gdjs.final_32level_324Code.eventsList7 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("ball_guy"), gdjs.final_32level_324Code.GDball_9595guyObjects2);
gdjs.copyArray(runtimeScene.getObjects("coin"), gdjs.final_32level_324Code.GDcoinObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects2Objects, gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDcoinObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.final_32level_324Code.GDcoinObjects2 */
{runtimeScene.getGame().getVariables().getFromIndex(2).add(1);
}
{for(var i = 0, len = gdjs.final_32level_324Code.GDcoinObjects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDcoinObjects2[i].deleteFromScene(runtimeScene);
}
}
{gdjs.evtTools.sound.playSound(runtimeScene, "coin soud2", false, 100, 1);
}
}

}


{


let isConditionTrue_0 = false;
{
}

}


};gdjs.final_32level_324Code.eventsList8 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() >= 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("boss_heart"), gdjs.final_32level_324Code.GDboss_9595heartObjects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDboss_9595heartObjects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDboss_9595heartObjects2[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() >= 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("boss_heart2"), gdjs.final_32level_324Code.GDboss_9595heart2Objects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDboss_9595heart2Objects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDboss_9595heart2Objects2[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() >= 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("boss_heart3"), gdjs.final_32level_324Code.GDboss_9595heart3Objects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDboss_9595heart3Objects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDboss_9595heart3Objects2[i].hide(false);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() <= 1);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("boss_heart"), gdjs.final_32level_324Code.GDboss_9595heartObjects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDboss_9595heartObjects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDboss_9595heartObjects2[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() <= 2);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("boss_heart2"), gdjs.final_32level_324Code.GDboss_9595heart2Objects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDboss_9595heart2Objects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDboss_9595heart2Objects2[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() <= 3);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("boss_heart3"), gdjs.final_32level_324Code.GDboss_9595heart3Objects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDboss_9595heart3Objects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDboss_9595heart3Objects2[i].hide();
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(1).getAsNumber() <= 0);
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "explosion", false);
}
}

}


};gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDlaserObjects2Objects = Hashtable.newFrom({"laser": gdjs.final_32level_324Code.GDlaserObjects2});
gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDevile_95959595guyObjects2Objects = Hashtable.newFrom({"evile_guy": gdjs.final_32level_324Code.GDevile_9595guyObjects2});
gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects2Objects = Hashtable.newFrom({"ball_guy": gdjs.final_32level_324Code.GDball_9595guyObjects2});
gdjs.final_32level_324Code.asyncCallback16494868 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.final_32level_324Code.localVariables);
gdjs.copyArray(runtimeScene.getObjects("laser"), gdjs.final_32level_324Code.GDlaserObjects2);
gdjs.final_32level_324Code.GDball_9595guyObjects2.length = 0;

{gdjs.evtTools.object.createObjectFromGroupOnScene(runtimeScene, gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDball_95959595guyObjects2Objects, "laser", gdjs.evtTools.common.toNumber("ball_guy") + 1, gdjs.evtTools.common.toNumber("ball_guy"), "");
}
{for(var i = 0, len = gdjs.final_32level_324Code.GDlaserObjects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDlaserObjects2[i].hide(false);
}
}
{runtimeScene.getScene().getVariables().getFromIndex(1).sub(3);
}
gdjs.final_32level_324Code.localVariables.length = 0;
}
gdjs.final_32level_324Code.idToCallbackMap.set(16494868, gdjs.final_32level_324Code.asyncCallback16494868);
gdjs.final_32level_324Code.eventsList9 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.final_32level_324Code.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(2), (runtimeScene) => (gdjs.final_32level_324Code.asyncCallback16494868(runtimeScene, asyncObjectsList)), 16494868, asyncObjectsList);
}
}

}


};gdjs.final_32level_324Code.eventsList10 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("evile_guy"), gdjs.final_32level_324Code.GDevile_9595guyObjects2);
gdjs.copyArray(runtimeScene.getObjects("laser"), gdjs.final_32level_324Code.GDlaserObjects2);
{for(var i = 0, len = gdjs.final_32level_324Code.GDlaserObjects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDlaserObjects2[i].hide(false);
}
}
{for(var i = 0, len = gdjs.final_32level_324Code.GDlaserObjects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDlaserObjects2[i].addForceTowardObject((gdjs.final_32level_324Code.GDevile_9595guyObjects2.length !== 0 ? gdjs.final_32level_324Code.GDevile_9595guyObjects2[0] : null), 99999999, 0);
}
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("evile_guy"), gdjs.final_32level_324Code.GDevile_9595guyObjects2);
gdjs.copyArray(runtimeScene.getObjects("laser"), gdjs.final_32level_324Code.GDlaserObjects2);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDlaserObjects2Objects, gdjs.final_32level_324Code.mapOfGDgdjs_9546final_959532level_9595324Code_9546GDevile_95959595guyObjects2Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16493476);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.final_32level_324Code.GDlaserObjects2 */
{runtimeScene.getScene().getVariables().getFromIndex(1).sub(1);
}
{for(var i = 0, len = gdjs.final_32level_324Code.GDlaserObjects2.length ;i < len;++i) {
    gdjs.final_32level_324Code.GDlaserObjects2[i].deleteFromScene(runtimeScene);
}
}
}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "s");
if (isConditionTrue_0) {

{ //Subevents
gdjs.final_32level_324Code.eventsList9(runtimeScene);} //End of subevents
}

}


};gdjs.final_32level_324Code.eventsList11 = function(runtimeScene) {

{


gdjs.final_32level_324Code.eventsList1(runtimeScene);
}


{


gdjs.final_32level_324Code.eventsList3(runtimeScene);
}


{


gdjs.final_32level_324Code.eventsList5(runtimeScene);
}


{


gdjs.final_32level_324Code.eventsList6(runtimeScene);
}


{


gdjs.final_32level_324Code.eventsList7(runtimeScene);
}


{


gdjs.final_32level_324Code.eventsList8(runtimeScene);
}


{


gdjs.final_32level_324Code.eventsList10(runtimeScene);
}


};

gdjs.final_32level_324Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.final_32level_324Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.final_32level_324Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.final_32level_324Code.GDNewTiledSpriteObjects3.length = 0;
gdjs.final_32level_324Code.GDlaserObjects1.length = 0;
gdjs.final_32level_324Code.GDlaserObjects2.length = 0;
gdjs.final_32level_324Code.GDlaserObjects3.length = 0;
gdjs.final_32level_324Code.GDNewTextObjects1.length = 0;
gdjs.final_32level_324Code.GDNewTextObjects2.length = 0;
gdjs.final_32level_324Code.GDNewTextObjects3.length = 0;
gdjs.final_32level_324Code.GDhearts_9595lifeObjects1.length = 0;
gdjs.final_32level_324Code.GDhearts_9595lifeObjects2.length = 0;
gdjs.final_32level_324Code.GDhearts_9595lifeObjects3.length = 0;
gdjs.final_32level_324Code.GDhearts_9595life2Objects1.length = 0;
gdjs.final_32level_324Code.GDhearts_9595life2Objects2.length = 0;
gdjs.final_32level_324Code.GDhearts_9595life2Objects3.length = 0;
gdjs.final_32level_324Code.GDhearts_9595life3Objects1.length = 0;
gdjs.final_32level_324Code.GDhearts_9595life3Objects2.length = 0;
gdjs.final_32level_324Code.GDhearts_9595life3Objects3.length = 0;
gdjs.final_32level_324Code.GDball_9595guyObjects1.length = 0;
gdjs.final_32level_324Code.GDball_9595guyObjects2.length = 0;
gdjs.final_32level_324Code.GDball_9595guyObjects3.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite_9595cloneObjects3.length = 0;
gdjs.final_32level_324Code.GDguy_9595spriteObjects1.length = 0;
gdjs.final_32level_324Code.GDguy_9595spriteObjects2.length = 0;
gdjs.final_32level_324Code.GDguy_9595spriteObjects3.length = 0;
gdjs.final_32level_324Code.GDtimekeeperObjects1.length = 0;
gdjs.final_32level_324Code.GDtimekeeperObjects2.length = 0;
gdjs.final_32level_324Code.GDtimekeeperObjects3.length = 0;
gdjs.final_32level_324Code.GDdeathblockObjects1.length = 0;
gdjs.final_32level_324Code.GDdeathblockObjects2.length = 0;
gdjs.final_32level_324Code.GDdeathblockObjects3.length = 0;
gdjs.final_32level_324Code.GDkey2Objects1.length = 0;
gdjs.final_32level_324Code.GDkey2Objects2.length = 0;
gdjs.final_32level_324Code.GDkey2Objects3.length = 0;
gdjs.final_32level_324Code.GDscoreboardObjects1.length = 0;
gdjs.final_32level_324Code.GDscoreboardObjects2.length = 0;
gdjs.final_32level_324Code.GDscoreboardObjects3.length = 0;
gdjs.final_32level_324Code.GDdoorObjects1.length = 0;
gdjs.final_32level_324Code.GDdoorObjects2.length = 0;
gdjs.final_32level_324Code.GDdoorObjects3.length = 0;
gdjs.final_32level_324Code.GDno_9595keyObjects1.length = 0;
gdjs.final_32level_324Code.GDno_9595keyObjects2.length = 0;
gdjs.final_32level_324Code.GDno_9595keyObjects3.length = 0;
gdjs.final_32level_324Code.GDcoinObjects1.length = 0;
gdjs.final_32level_324Code.GDcoinObjects2.length = 0;
gdjs.final_32level_324Code.GDcoinObjects3.length = 0;
gdjs.final_32level_324Code.GDplatform_9595viruseObjects1.length = 0;
gdjs.final_32level_324Code.GDplatform_9595viruseObjects2.length = 0;
gdjs.final_32level_324Code.GDplatform_9595viruseObjects3.length = 0;
gdjs.final_32level_324Code.GDboss_9595heartObjects1.length = 0;
gdjs.final_32level_324Code.GDboss_9595heartObjects2.length = 0;
gdjs.final_32level_324Code.GDboss_9595heartObjects3.length = 0;
gdjs.final_32level_324Code.GDboss_9595heart2Objects1.length = 0;
gdjs.final_32level_324Code.GDboss_9595heart2Objects2.length = 0;
gdjs.final_32level_324Code.GDboss_9595heart2Objects3.length = 0;
gdjs.final_32level_324Code.GDboss_9595heart3Objects1.length = 0;
gdjs.final_32level_324Code.GDboss_9595heart3Objects2.length = 0;
gdjs.final_32level_324Code.GDboss_9595heart3Objects3.length = 0;
gdjs.final_32level_324Code.GDevile_9595guyObjects1.length = 0;
gdjs.final_32level_324Code.GDevile_9595guyObjects2.length = 0;
gdjs.final_32level_324Code.GDevile_9595guyObjects3.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite2Objects1.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite2Objects2.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite2Objects3.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite_9595clone2Objects2.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite_9595clone2Objects3.length = 0;

gdjs.final_32level_324Code.eventsList11(runtimeScene);
gdjs.final_32level_324Code.GDNewTiledSpriteObjects1.length = 0;
gdjs.final_32level_324Code.GDNewTiledSpriteObjects2.length = 0;
gdjs.final_32level_324Code.GDNewTiledSpriteObjects3.length = 0;
gdjs.final_32level_324Code.GDlaserObjects1.length = 0;
gdjs.final_32level_324Code.GDlaserObjects2.length = 0;
gdjs.final_32level_324Code.GDlaserObjects3.length = 0;
gdjs.final_32level_324Code.GDNewTextObjects1.length = 0;
gdjs.final_32level_324Code.GDNewTextObjects2.length = 0;
gdjs.final_32level_324Code.GDNewTextObjects3.length = 0;
gdjs.final_32level_324Code.GDhearts_9595lifeObjects1.length = 0;
gdjs.final_32level_324Code.GDhearts_9595lifeObjects2.length = 0;
gdjs.final_32level_324Code.GDhearts_9595lifeObjects3.length = 0;
gdjs.final_32level_324Code.GDhearts_9595life2Objects1.length = 0;
gdjs.final_32level_324Code.GDhearts_9595life2Objects2.length = 0;
gdjs.final_32level_324Code.GDhearts_9595life2Objects3.length = 0;
gdjs.final_32level_324Code.GDhearts_9595life3Objects1.length = 0;
gdjs.final_32level_324Code.GDhearts_9595life3Objects2.length = 0;
gdjs.final_32level_324Code.GDhearts_9595life3Objects3.length = 0;
gdjs.final_32level_324Code.GDball_9595guyObjects1.length = 0;
gdjs.final_32level_324Code.GDball_9595guyObjects2.length = 0;
gdjs.final_32level_324Code.GDball_9595guyObjects3.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite_9595cloneObjects3.length = 0;
gdjs.final_32level_324Code.GDguy_9595spriteObjects1.length = 0;
gdjs.final_32level_324Code.GDguy_9595spriteObjects2.length = 0;
gdjs.final_32level_324Code.GDguy_9595spriteObjects3.length = 0;
gdjs.final_32level_324Code.GDtimekeeperObjects1.length = 0;
gdjs.final_32level_324Code.GDtimekeeperObjects2.length = 0;
gdjs.final_32level_324Code.GDtimekeeperObjects3.length = 0;
gdjs.final_32level_324Code.GDdeathblockObjects1.length = 0;
gdjs.final_32level_324Code.GDdeathblockObjects2.length = 0;
gdjs.final_32level_324Code.GDdeathblockObjects3.length = 0;
gdjs.final_32level_324Code.GDkey2Objects1.length = 0;
gdjs.final_32level_324Code.GDkey2Objects2.length = 0;
gdjs.final_32level_324Code.GDkey2Objects3.length = 0;
gdjs.final_32level_324Code.GDscoreboardObjects1.length = 0;
gdjs.final_32level_324Code.GDscoreboardObjects2.length = 0;
gdjs.final_32level_324Code.GDscoreboardObjects3.length = 0;
gdjs.final_32level_324Code.GDdoorObjects1.length = 0;
gdjs.final_32level_324Code.GDdoorObjects2.length = 0;
gdjs.final_32level_324Code.GDdoorObjects3.length = 0;
gdjs.final_32level_324Code.GDno_9595keyObjects1.length = 0;
gdjs.final_32level_324Code.GDno_9595keyObjects2.length = 0;
gdjs.final_32level_324Code.GDno_9595keyObjects3.length = 0;
gdjs.final_32level_324Code.GDcoinObjects1.length = 0;
gdjs.final_32level_324Code.GDcoinObjects2.length = 0;
gdjs.final_32level_324Code.GDcoinObjects3.length = 0;
gdjs.final_32level_324Code.GDplatform_9595viruseObjects1.length = 0;
gdjs.final_32level_324Code.GDplatform_9595viruseObjects2.length = 0;
gdjs.final_32level_324Code.GDplatform_9595viruseObjects3.length = 0;
gdjs.final_32level_324Code.GDboss_9595heartObjects1.length = 0;
gdjs.final_32level_324Code.GDboss_9595heartObjects2.length = 0;
gdjs.final_32level_324Code.GDboss_9595heartObjects3.length = 0;
gdjs.final_32level_324Code.GDboss_9595heart2Objects1.length = 0;
gdjs.final_32level_324Code.GDboss_9595heart2Objects2.length = 0;
gdjs.final_32level_324Code.GDboss_9595heart2Objects3.length = 0;
gdjs.final_32level_324Code.GDboss_9595heart3Objects1.length = 0;
gdjs.final_32level_324Code.GDboss_9595heart3Objects2.length = 0;
gdjs.final_32level_324Code.GDboss_9595heart3Objects3.length = 0;
gdjs.final_32level_324Code.GDevile_9595guyObjects1.length = 0;
gdjs.final_32level_324Code.GDevile_9595guyObjects2.length = 0;
gdjs.final_32level_324Code.GDevile_9595guyObjects3.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite2Objects1.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite2Objects2.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite2Objects3.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite_9595clone2Objects2.length = 0;
gdjs.final_32level_324Code.GDguy_9595sprite_9595clone2Objects3.length = 0;


return;

}

gdjs['final_32level_324Code'] = gdjs.final_32level_324Code;
