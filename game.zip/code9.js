gdjs.final_32sceneCode = {};
gdjs.final_32sceneCode.localVariables = [];
gdjs.final_32sceneCode.idToCallbackMap = new Map();
gdjs.final_32sceneCode.GDNewSpriteObjects1= [];
gdjs.final_32sceneCode.GDNewSpriteObjects2= [];
gdjs.final_32sceneCode.GDhearts_9595lifeObjects1= [];
gdjs.final_32sceneCode.GDhearts_9595lifeObjects2= [];
gdjs.final_32sceneCode.GDhearts_9595life2Objects1= [];
gdjs.final_32sceneCode.GDhearts_9595life2Objects2= [];
gdjs.final_32sceneCode.GDhearts_9595life3Objects1= [];
gdjs.final_32sceneCode.GDhearts_9595life3Objects2= [];
gdjs.final_32sceneCode.GDball_9595guyObjects1= [];
gdjs.final_32sceneCode.GDball_9595guyObjects2= [];
gdjs.final_32sceneCode.GDguy_9595sprite_9595cloneObjects1= [];
gdjs.final_32sceneCode.GDguy_9595sprite_9595cloneObjects2= [];
gdjs.final_32sceneCode.GDguy_9595spriteObjects1= [];
gdjs.final_32sceneCode.GDguy_9595spriteObjects2= [];
gdjs.final_32sceneCode.GDtimekeeperObjects1= [];
gdjs.final_32sceneCode.GDtimekeeperObjects2= [];
gdjs.final_32sceneCode.GDdeathblockObjects1= [];
gdjs.final_32sceneCode.GDdeathblockObjects2= [];
gdjs.final_32sceneCode.GDkey2Objects1= [];
gdjs.final_32sceneCode.GDkey2Objects2= [];
gdjs.final_32sceneCode.GDscoreboardObjects1= [];
gdjs.final_32sceneCode.GDscoreboardObjects2= [];
gdjs.final_32sceneCode.GDdoorObjects1= [];
gdjs.final_32sceneCode.GDdoorObjects2= [];
gdjs.final_32sceneCode.GDno_9595keyObjects1= [];
gdjs.final_32sceneCode.GDno_9595keyObjects2= [];
gdjs.final_32sceneCode.GDcoinObjects1= [];
gdjs.final_32sceneCode.GDcoinObjects2= [];
gdjs.final_32sceneCode.GDplatform_9595viruseObjects1= [];
gdjs.final_32sceneCode.GDplatform_9595viruseObjects2= [];
gdjs.final_32sceneCode.GDboss_9595heartObjects1= [];
gdjs.final_32sceneCode.GDboss_9595heartObjects2= [];
gdjs.final_32sceneCode.GDboss_9595heart2Objects1= [];
gdjs.final_32sceneCode.GDboss_9595heart2Objects2= [];
gdjs.final_32sceneCode.GDboss_9595heart3Objects1= [];
gdjs.final_32sceneCode.GDboss_9595heart3Objects2= [];
gdjs.final_32sceneCode.GDevile_9595guyObjects1= [];
gdjs.final_32sceneCode.GDevile_9595guyObjects2= [];
gdjs.final_32sceneCode.GDguy_9595sprite2Objects1= [];
gdjs.final_32sceneCode.GDguy_9595sprite2Objects2= [];
gdjs.final_32sceneCode.GDguy_9595sprite_9595clone2Objects1= [];
gdjs.final_32sceneCode.GDguy_9595sprite_9595clone2Objects2= [];


gdjs.final_32sceneCode.asyncCallback16561444 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.final_32sceneCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "sneak peak", false);
}
gdjs.final_32sceneCode.localVariables.length = 0;
}
gdjs.final_32sceneCode.idToCallbackMap.set(16561444, gdjs.final_32sceneCode.asyncCallback16561444);
gdjs.final_32sceneCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.final_32sceneCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(30), (runtimeScene) => (gdjs.final_32sceneCode.asyncCallback16561444(runtimeScene, asyncObjectsList)), 16561444, asyncObjectsList);
}
}

}


};gdjs.final_32sceneCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.final_32sceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.final_32sceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.final_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.final_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.final_32sceneCode.GDhearts_9595lifeObjects1.length = 0;
gdjs.final_32sceneCode.GDhearts_9595lifeObjects2.length = 0;
gdjs.final_32sceneCode.GDhearts_9595life2Objects1.length = 0;
gdjs.final_32sceneCode.GDhearts_9595life2Objects2.length = 0;
gdjs.final_32sceneCode.GDhearts_9595life3Objects1.length = 0;
gdjs.final_32sceneCode.GDhearts_9595life3Objects2.length = 0;
gdjs.final_32sceneCode.GDball_9595guyObjects1.length = 0;
gdjs.final_32sceneCode.GDball_9595guyObjects2.length = 0;
gdjs.final_32sceneCode.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.final_32sceneCode.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.final_32sceneCode.GDguy_9595spriteObjects1.length = 0;
gdjs.final_32sceneCode.GDguy_9595spriteObjects2.length = 0;
gdjs.final_32sceneCode.GDtimekeeperObjects1.length = 0;
gdjs.final_32sceneCode.GDtimekeeperObjects2.length = 0;
gdjs.final_32sceneCode.GDdeathblockObjects1.length = 0;
gdjs.final_32sceneCode.GDdeathblockObjects2.length = 0;
gdjs.final_32sceneCode.GDkey2Objects1.length = 0;
gdjs.final_32sceneCode.GDkey2Objects2.length = 0;
gdjs.final_32sceneCode.GDscoreboardObjects1.length = 0;
gdjs.final_32sceneCode.GDscoreboardObjects2.length = 0;
gdjs.final_32sceneCode.GDdoorObjects1.length = 0;
gdjs.final_32sceneCode.GDdoorObjects2.length = 0;
gdjs.final_32sceneCode.GDno_9595keyObjects1.length = 0;
gdjs.final_32sceneCode.GDno_9595keyObjects2.length = 0;
gdjs.final_32sceneCode.GDcoinObjects1.length = 0;
gdjs.final_32sceneCode.GDcoinObjects2.length = 0;
gdjs.final_32sceneCode.GDplatform_9595viruseObjects1.length = 0;
gdjs.final_32sceneCode.GDplatform_9595viruseObjects2.length = 0;
gdjs.final_32sceneCode.GDboss_9595heartObjects1.length = 0;
gdjs.final_32sceneCode.GDboss_9595heartObjects2.length = 0;
gdjs.final_32sceneCode.GDboss_9595heart2Objects1.length = 0;
gdjs.final_32sceneCode.GDboss_9595heart2Objects2.length = 0;
gdjs.final_32sceneCode.GDboss_9595heart3Objects1.length = 0;
gdjs.final_32sceneCode.GDboss_9595heart3Objects2.length = 0;
gdjs.final_32sceneCode.GDevile_9595guyObjects1.length = 0;
gdjs.final_32sceneCode.GDevile_9595guyObjects2.length = 0;
gdjs.final_32sceneCode.GDguy_9595sprite2Objects1.length = 0;
gdjs.final_32sceneCode.GDguy_9595sprite2Objects2.length = 0;
gdjs.final_32sceneCode.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.final_32sceneCode.GDguy_9595sprite_9595clone2Objects2.length = 0;

gdjs.final_32sceneCode.eventsList1(runtimeScene);
gdjs.final_32sceneCode.GDNewSpriteObjects1.length = 0;
gdjs.final_32sceneCode.GDNewSpriteObjects2.length = 0;
gdjs.final_32sceneCode.GDhearts_9595lifeObjects1.length = 0;
gdjs.final_32sceneCode.GDhearts_9595lifeObjects2.length = 0;
gdjs.final_32sceneCode.GDhearts_9595life2Objects1.length = 0;
gdjs.final_32sceneCode.GDhearts_9595life2Objects2.length = 0;
gdjs.final_32sceneCode.GDhearts_9595life3Objects1.length = 0;
gdjs.final_32sceneCode.GDhearts_9595life3Objects2.length = 0;
gdjs.final_32sceneCode.GDball_9595guyObjects1.length = 0;
gdjs.final_32sceneCode.GDball_9595guyObjects2.length = 0;
gdjs.final_32sceneCode.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.final_32sceneCode.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.final_32sceneCode.GDguy_9595spriteObjects1.length = 0;
gdjs.final_32sceneCode.GDguy_9595spriteObjects2.length = 0;
gdjs.final_32sceneCode.GDtimekeeperObjects1.length = 0;
gdjs.final_32sceneCode.GDtimekeeperObjects2.length = 0;
gdjs.final_32sceneCode.GDdeathblockObjects1.length = 0;
gdjs.final_32sceneCode.GDdeathblockObjects2.length = 0;
gdjs.final_32sceneCode.GDkey2Objects1.length = 0;
gdjs.final_32sceneCode.GDkey2Objects2.length = 0;
gdjs.final_32sceneCode.GDscoreboardObjects1.length = 0;
gdjs.final_32sceneCode.GDscoreboardObjects2.length = 0;
gdjs.final_32sceneCode.GDdoorObjects1.length = 0;
gdjs.final_32sceneCode.GDdoorObjects2.length = 0;
gdjs.final_32sceneCode.GDno_9595keyObjects1.length = 0;
gdjs.final_32sceneCode.GDno_9595keyObjects2.length = 0;
gdjs.final_32sceneCode.GDcoinObjects1.length = 0;
gdjs.final_32sceneCode.GDcoinObjects2.length = 0;
gdjs.final_32sceneCode.GDplatform_9595viruseObjects1.length = 0;
gdjs.final_32sceneCode.GDplatform_9595viruseObjects2.length = 0;
gdjs.final_32sceneCode.GDboss_9595heartObjects1.length = 0;
gdjs.final_32sceneCode.GDboss_9595heartObjects2.length = 0;
gdjs.final_32sceneCode.GDboss_9595heart2Objects1.length = 0;
gdjs.final_32sceneCode.GDboss_9595heart2Objects2.length = 0;
gdjs.final_32sceneCode.GDboss_9595heart3Objects1.length = 0;
gdjs.final_32sceneCode.GDboss_9595heart3Objects2.length = 0;
gdjs.final_32sceneCode.GDevile_9595guyObjects1.length = 0;
gdjs.final_32sceneCode.GDevile_9595guyObjects2.length = 0;
gdjs.final_32sceneCode.GDguy_9595sprite2Objects1.length = 0;
gdjs.final_32sceneCode.GDguy_9595sprite2Objects2.length = 0;
gdjs.final_32sceneCode.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.final_32sceneCode.GDguy_9595sprite_9595clone2Objects2.length = 0;


return;

}

gdjs['final_32sceneCode'] = gdjs.final_32sceneCode;
