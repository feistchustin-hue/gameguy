gdjs.sneak_32peakCode = {};
gdjs.sneak_32peakCode.localVariables = [];
gdjs.sneak_32peakCode.idToCallbackMap = new Map();
gdjs.sneak_32peakCode.GDNewSpriteObjects1= [];
gdjs.sneak_32peakCode.GDNewSpriteObjects2= [];
gdjs.sneak_32peakCode.GDhearts_9595lifeObjects1= [];
gdjs.sneak_32peakCode.GDhearts_9595lifeObjects2= [];
gdjs.sneak_32peakCode.GDhearts_9595life2Objects1= [];
gdjs.sneak_32peakCode.GDhearts_9595life2Objects2= [];
gdjs.sneak_32peakCode.GDhearts_9595life3Objects1= [];
gdjs.sneak_32peakCode.GDhearts_9595life3Objects2= [];
gdjs.sneak_32peakCode.GDball_9595guyObjects1= [];
gdjs.sneak_32peakCode.GDball_9595guyObjects2= [];
gdjs.sneak_32peakCode.GDguy_9595sprite_9595cloneObjects1= [];
gdjs.sneak_32peakCode.GDguy_9595sprite_9595cloneObjects2= [];
gdjs.sneak_32peakCode.GDguy_9595spriteObjects1= [];
gdjs.sneak_32peakCode.GDguy_9595spriteObjects2= [];
gdjs.sneak_32peakCode.GDtimekeeperObjects1= [];
gdjs.sneak_32peakCode.GDtimekeeperObjects2= [];
gdjs.sneak_32peakCode.GDdeathblockObjects1= [];
gdjs.sneak_32peakCode.GDdeathblockObjects2= [];
gdjs.sneak_32peakCode.GDkey2Objects1= [];
gdjs.sneak_32peakCode.GDkey2Objects2= [];
gdjs.sneak_32peakCode.GDscoreboardObjects1= [];
gdjs.sneak_32peakCode.GDscoreboardObjects2= [];
gdjs.sneak_32peakCode.GDdoorObjects1= [];
gdjs.sneak_32peakCode.GDdoorObjects2= [];
gdjs.sneak_32peakCode.GDno_9595keyObjects1= [];
gdjs.sneak_32peakCode.GDno_9595keyObjects2= [];
gdjs.sneak_32peakCode.GDcoinObjects1= [];
gdjs.sneak_32peakCode.GDcoinObjects2= [];
gdjs.sneak_32peakCode.GDplatform_9595viruseObjects1= [];
gdjs.sneak_32peakCode.GDplatform_9595viruseObjects2= [];
gdjs.sneak_32peakCode.GDboss_9595heartObjects1= [];
gdjs.sneak_32peakCode.GDboss_9595heartObjects2= [];
gdjs.sneak_32peakCode.GDboss_9595heart2Objects1= [];
gdjs.sneak_32peakCode.GDboss_9595heart2Objects2= [];
gdjs.sneak_32peakCode.GDboss_9595heart3Objects1= [];
gdjs.sneak_32peakCode.GDboss_9595heart3Objects2= [];
gdjs.sneak_32peakCode.GDevile_9595guyObjects1= [];
gdjs.sneak_32peakCode.GDevile_9595guyObjects2= [];
gdjs.sneak_32peakCode.GDguy_9595sprite2Objects1= [];
gdjs.sneak_32peakCode.GDguy_9595sprite2Objects2= [];
gdjs.sneak_32peakCode.GDguy_9595sprite_9595clone2Objects1= [];
gdjs.sneak_32peakCode.GDguy_9595sprite_9595clone2Objects2= [];


gdjs.sneak_32peakCode.asyncCallback16589404 = function (runtimeScene, asyncObjectsList) {
asyncObjectsList.restoreLocalVariablesContainers(gdjs.sneak_32peakCode.localVariables);
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "the end", false);
}
gdjs.sneak_32peakCode.localVariables.length = 0;
}
gdjs.sneak_32peakCode.idToCallbackMap.set(16589404, gdjs.sneak_32peakCode.asyncCallback16589404);
gdjs.sneak_32peakCode.eventsList0 = function(runtimeScene) {

{


{
{
const asyncObjectsList = new gdjs.LongLivedObjectsList();
asyncObjectsList.backupLocalVariablesContainers(gdjs.sneak_32peakCode.localVariables);
runtimeScene.getAsyncTasksManager().addTask(gdjs.evtTools.runtimeScene.wait(10), (runtimeScene) => (gdjs.sneak_32peakCode.asyncCallback16589404(runtimeScene, asyncObjectsList)), 16589404, asyncObjectsList);
}
}

}


};gdjs.sneak_32peakCode.eventsList1 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {

{ //Subevents
gdjs.sneak_32peakCode.eventsList0(runtimeScene);} //End of subevents
}

}


};

gdjs.sneak_32peakCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.sneak_32peakCode.GDNewSpriteObjects1.length = 0;
gdjs.sneak_32peakCode.GDNewSpriteObjects2.length = 0;
gdjs.sneak_32peakCode.GDhearts_9595lifeObjects1.length = 0;
gdjs.sneak_32peakCode.GDhearts_9595lifeObjects2.length = 0;
gdjs.sneak_32peakCode.GDhearts_9595life2Objects1.length = 0;
gdjs.sneak_32peakCode.GDhearts_9595life2Objects2.length = 0;
gdjs.sneak_32peakCode.GDhearts_9595life3Objects1.length = 0;
gdjs.sneak_32peakCode.GDhearts_9595life3Objects2.length = 0;
gdjs.sneak_32peakCode.GDball_9595guyObjects1.length = 0;
gdjs.sneak_32peakCode.GDball_9595guyObjects2.length = 0;
gdjs.sneak_32peakCode.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.sneak_32peakCode.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.sneak_32peakCode.GDguy_9595spriteObjects1.length = 0;
gdjs.sneak_32peakCode.GDguy_9595spriteObjects2.length = 0;
gdjs.sneak_32peakCode.GDtimekeeperObjects1.length = 0;
gdjs.sneak_32peakCode.GDtimekeeperObjects2.length = 0;
gdjs.sneak_32peakCode.GDdeathblockObjects1.length = 0;
gdjs.sneak_32peakCode.GDdeathblockObjects2.length = 0;
gdjs.sneak_32peakCode.GDkey2Objects1.length = 0;
gdjs.sneak_32peakCode.GDkey2Objects2.length = 0;
gdjs.sneak_32peakCode.GDscoreboardObjects1.length = 0;
gdjs.sneak_32peakCode.GDscoreboardObjects2.length = 0;
gdjs.sneak_32peakCode.GDdoorObjects1.length = 0;
gdjs.sneak_32peakCode.GDdoorObjects2.length = 0;
gdjs.sneak_32peakCode.GDno_9595keyObjects1.length = 0;
gdjs.sneak_32peakCode.GDno_9595keyObjects2.length = 0;
gdjs.sneak_32peakCode.GDcoinObjects1.length = 0;
gdjs.sneak_32peakCode.GDcoinObjects2.length = 0;
gdjs.sneak_32peakCode.GDplatform_9595viruseObjects1.length = 0;
gdjs.sneak_32peakCode.GDplatform_9595viruseObjects2.length = 0;
gdjs.sneak_32peakCode.GDboss_9595heartObjects1.length = 0;
gdjs.sneak_32peakCode.GDboss_9595heartObjects2.length = 0;
gdjs.sneak_32peakCode.GDboss_9595heart2Objects1.length = 0;
gdjs.sneak_32peakCode.GDboss_9595heart2Objects2.length = 0;
gdjs.sneak_32peakCode.GDboss_9595heart3Objects1.length = 0;
gdjs.sneak_32peakCode.GDboss_9595heart3Objects2.length = 0;
gdjs.sneak_32peakCode.GDevile_9595guyObjects1.length = 0;
gdjs.sneak_32peakCode.GDevile_9595guyObjects2.length = 0;
gdjs.sneak_32peakCode.GDguy_9595sprite2Objects1.length = 0;
gdjs.sneak_32peakCode.GDguy_9595sprite2Objects2.length = 0;
gdjs.sneak_32peakCode.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.sneak_32peakCode.GDguy_9595sprite_9595clone2Objects2.length = 0;

gdjs.sneak_32peakCode.eventsList1(runtimeScene);
gdjs.sneak_32peakCode.GDNewSpriteObjects1.length = 0;
gdjs.sneak_32peakCode.GDNewSpriteObjects2.length = 0;
gdjs.sneak_32peakCode.GDhearts_9595lifeObjects1.length = 0;
gdjs.sneak_32peakCode.GDhearts_9595lifeObjects2.length = 0;
gdjs.sneak_32peakCode.GDhearts_9595life2Objects1.length = 0;
gdjs.sneak_32peakCode.GDhearts_9595life2Objects2.length = 0;
gdjs.sneak_32peakCode.GDhearts_9595life3Objects1.length = 0;
gdjs.sneak_32peakCode.GDhearts_9595life3Objects2.length = 0;
gdjs.sneak_32peakCode.GDball_9595guyObjects1.length = 0;
gdjs.sneak_32peakCode.GDball_9595guyObjects2.length = 0;
gdjs.sneak_32peakCode.GDguy_9595sprite_9595cloneObjects1.length = 0;
gdjs.sneak_32peakCode.GDguy_9595sprite_9595cloneObjects2.length = 0;
gdjs.sneak_32peakCode.GDguy_9595spriteObjects1.length = 0;
gdjs.sneak_32peakCode.GDguy_9595spriteObjects2.length = 0;
gdjs.sneak_32peakCode.GDtimekeeperObjects1.length = 0;
gdjs.sneak_32peakCode.GDtimekeeperObjects2.length = 0;
gdjs.sneak_32peakCode.GDdeathblockObjects1.length = 0;
gdjs.sneak_32peakCode.GDdeathblockObjects2.length = 0;
gdjs.sneak_32peakCode.GDkey2Objects1.length = 0;
gdjs.sneak_32peakCode.GDkey2Objects2.length = 0;
gdjs.sneak_32peakCode.GDscoreboardObjects1.length = 0;
gdjs.sneak_32peakCode.GDscoreboardObjects2.length = 0;
gdjs.sneak_32peakCode.GDdoorObjects1.length = 0;
gdjs.sneak_32peakCode.GDdoorObjects2.length = 0;
gdjs.sneak_32peakCode.GDno_9595keyObjects1.length = 0;
gdjs.sneak_32peakCode.GDno_9595keyObjects2.length = 0;
gdjs.sneak_32peakCode.GDcoinObjects1.length = 0;
gdjs.sneak_32peakCode.GDcoinObjects2.length = 0;
gdjs.sneak_32peakCode.GDplatform_9595viruseObjects1.length = 0;
gdjs.sneak_32peakCode.GDplatform_9595viruseObjects2.length = 0;
gdjs.sneak_32peakCode.GDboss_9595heartObjects1.length = 0;
gdjs.sneak_32peakCode.GDboss_9595heartObjects2.length = 0;
gdjs.sneak_32peakCode.GDboss_9595heart2Objects1.length = 0;
gdjs.sneak_32peakCode.GDboss_9595heart2Objects2.length = 0;
gdjs.sneak_32peakCode.GDboss_9595heart3Objects1.length = 0;
gdjs.sneak_32peakCode.GDboss_9595heart3Objects2.length = 0;
gdjs.sneak_32peakCode.GDevile_9595guyObjects1.length = 0;
gdjs.sneak_32peakCode.GDevile_9595guyObjects2.length = 0;
gdjs.sneak_32peakCode.GDguy_9595sprite2Objects1.length = 0;
gdjs.sneak_32peakCode.GDguy_9595sprite2Objects2.length = 0;
gdjs.sneak_32peakCode.GDguy_9595sprite_9595clone2Objects1.length = 0;
gdjs.sneak_32peakCode.GDguy_9595sprite_9595clone2Objects2.length = 0;


return;

}

gdjs['sneak_32peakCode'] = gdjs.sneak_32peakCode;
